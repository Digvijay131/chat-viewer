export type MessageType =
  | 'text'
  | 'image'
  | 'video'
  | 'audio'
  | 'sticker'
  | 'document'
  | 'location'
  | 'contact'
  | 'call'
  | 'deleted'
  | 'system';

export interface MediaDetails {
  mediaType: 'image' | 'video' | 'audio' | 'sticker' | 'document' | 'location' | 'contact' | 'call';
  filename?: string;
  fileSize?: string;
  duration?: string;
  url?: string;
  caption?: string;
}

export interface ChatMessage {
  id: string;
  rawTimestamp: string;
  timestamp: number; // Unix Epoch in ms
  dateStr: string; // Formatted YYYY-MM-DD
  displayDate: string; // Formatted human readable (e.g. 12 August 2024)
  timeStr: string; // Formatted e.g. "10:32 PM" or "22:32"
  sender: string;
  content: string;
  type: MessageType;
  mediaDetails?: MediaDetails;
  isSystemMessage: boolean;
  isMedia: boolean;
  isDeleted: boolean;
  isOutgoing: boolean;
  lineIndex: number;
}

export interface ChatParticipant {
  name: string;
  messageCount: number;
  mediaCount: number;
  percentage: number;
  firstActive: number;
  lastActive: number;
  color: string;
}

export interface HourlyActivity {
  hour: number; // 0 - 23
  count: number;
}

export interface DailyActivity {
  dayOfWeek: number; // 0=Sun, 1=Mon, ..., 6=Sat
  dayName: string;
  count: number;
}

export interface MonthlyActivity {
  monthKey: string; // YYYY-MM
  label: string;
  count: number;
}

export interface EmojiStat {
  emoji: string;
  count: number;
}

export interface ChatStatistics {
  totalMessages: number;
  totalWords: number;
  mediaCount: number;
  deletedCount: number;
  systemMessageCount: number;
  linkCount: number;
  participantCount: number;
  firstMessageDate: Date | null;
  lastMessageDate: Date | null;
  durationDays: number;
  mostActiveParticipant: {
    name: string;
    count: number;
    percentage: number;
  } | null;
  participants: ChatParticipant[];
  hourlyActivity: HourlyActivity[];
  dailyActivity: DailyActivity[];
  monthlyActivity: MonthlyActivity[];
  topEmojis: EmojiStat[];
}

export interface ChatExportData {
  title: string;
  isGroupChat: boolean;
  detectedFormat: string;
  fileName: string;
  fileSizeBytes: number;
  messages: ChatMessage[];
  participants: ChatParticipant[];
  mySenderName: string;
  stats: ChatStatistics;
}

export interface ParseResult {
  success: boolean;
  data?: ChatExportData;
  error?: string;
  rawSample?: string;
  detectedFormatName?: string;
}

export type ThemeMode = 'light' | 'dark' | 'system';
export type FontSizeOption = 'small' | 'medium' | 'large';
