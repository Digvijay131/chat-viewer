import React, { useState, useEffect } from 'react';
import { ChatExportData, ThemeMode, FontSizeOption } from './types/chat';
import { parseWhatsAppChat } from './utils/whatsappParser';
import { SampleChatPreset } from './utils/sampleChats';
import { FileUploader } from './components/FileUploader';
import { ChatViewer } from './components/ChatViewer';
import { FormatErrorModal } from './components/FormatErrorModal';

export default function App() {
  const [chatData, setChatData] = useState<ChatExportData | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState<{ message: string; rawSample?: string } | null>(
    null
  );

  // Settings state with persistence in localStorage if available
  const [theme, setTheme] = useState<ThemeMode>(() => {
    return (localStorage.getItem('chatviewer_theme') as ThemeMode) || 'system';
  });

  const [fontSize, setFontSize] = useState<FontSizeOption>(() => {
    return (localStorage.getItem('chatviewer_fontsize') as FontSizeOption) || 'medium';
  });

  const [systemIsDark, setSystemIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Track system theme changes
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemIsDark(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  const isDark = theme === 'dark' || (theme === 'system' && systemIsDark);

  // Update HTML class for dark mode
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const handleSetTheme = (newTheme: ThemeMode) => {
    setTheme(newTheme);
    localStorage.setItem('chatviewer_theme', newTheme);
  };

  const handleSetFontSize = (newSize: FontSizeOption) => {
    setFontSize(newSize);
    localStorage.setItem('chatviewer_fontsize', newSize);
  };

  // Process text file content
  const handleParseContent = (content: string, fileName: string) => {
    setIsParsing(true);
    setParseError(null);

    // Use setTimeout to ensure UI shows parsing state for large files
    setTimeout(() => {
      try {
        const result = parseWhatsAppChat(content, fileName);
        if (result.success && result.data) {
          setChatData(result.data);
        } else {
          setParseError({
            message: result.error || 'Unable to recognize this WhatsApp export format.',
            rawSample: result.rawSample,
          });
        }
      } catch (err) {
        setParseError({
          message: 'An error occurred while parsing the chat file.',
          rawSample: content.slice(0, 300),
        });
      } finally {
        setIsParsing(false);
      }
    }, 120);
  };

  // Load sample preset
  const handleSelectSample = (sample: SampleChatPreset) => {
    handleParseContent(sample.content, sample.filename);
  };

  // Switch "Me" sender identity
  const handleUpdateMySender = (newMeSender: string) => {
    if (!chatData) return;

    const updatedMessages = chatData.messages.map((msg) => ({
      ...msg,
      isOutgoing:
        !msg.isSystemMessage &&
        Boolean(newMeSender) &&
        msg.sender.toLowerCase() === newMeSender.toLowerCase(),
    }));

    setChatData({
      ...chatData,
      mySenderName: newMeSender,
      messages: updatedMessages,
    });
  };

  return (
    <div className={`min-h-screen ${isDark ? 'dark bg-[#0b141a]' : 'bg-[#f0f2f5]'}`}>
      {!chatData ? (
        <FileUploader
          onFileLoaded={handleParseContent}
          onSelectSample={handleSelectSample}
          isParsing={isParsing}
          theme={theme}
          onSetTheme={handleSetTheme}
          isDark={isDark}
        />
      ) : (
        <ChatViewer
          chatData={chatData}
          onBack={() => setChatData(null)}
          theme={theme}
          onSetTheme={handleSetTheme}
          fontSize={fontSize}
          onSetFontSize={handleSetFontSize}
          onUpdateMySender={handleUpdateMySender}
          isDark={isDark}
        />
      )}

      {/* Format Error Diagnostic Modal */}
      <FormatErrorModal
        isOpen={Boolean(parseError)}
        onClose={() => setParseError(null)}
        errorMessage={parseError?.message}
        rawSample={parseError?.rawSample}
        onTrySample={() => {
          setParseError(null);
          // Try the first sample
          handleSelectSample({
            id: 'weekend-trip',
            name: 'Weekend Trip Planning 🏖️',
            description: '4 participants, itinerary discussions, photos, locations, and reactions',
            icon: 'Users',
            filename: 'WhatsApp Chat - Weekend Trip Planning.txt',
            content: `12/08/2024, 09:15 - Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them.
12/08/2024, 09:18 - Alex: Hey everyone! Excited for our coastal road trip this weekend 🚗✨
12/08/2024, 09:20 - Sarah: Can't wait! Did anyone check the weather forecast for Saturday?
12/08/2024, 09:21 - David: <Media omitted>
12/08/2024, 09:22 - David: 75°F and sunny all weekend! Perfect beach weather ☀️😎`,
          });
        }}
        isDark={isDark}
      />
    </div>
  );
}
