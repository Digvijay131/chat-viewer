export interface SampleChatPreset {
  id: string;
  name: string;
  description: string;
  icon: string;
  filename: string;
  content: string;
}

export const SAMPLE_CHATS: SampleChatPreset[] = [
  {
    id: 'weekend-trip',
    name: 'Weekend Trip Planning 🏖️',
    description: '4 participants, itinerary discussions, photos, locations, and reactions',
    icon: 'Users',
    filename: 'WhatsApp Chat - Weekend Trip Planning.txt',
    content: `12/08/2024, 09:15 - Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them.
12/08/2024, 09:16 - Alex created group "Weekend Trip Planning 🏖️"
12/08/2024, 09:16 - Alex added Sarah, David, and Maya
12/08/2024, 09:18 - Alex: Hey everyone! Excited for our coastal road trip this weekend 🚗✨
12/08/2024, 09:20 - Sarah: Can't wait! Did anyone check the weather forecast for Saturday?
12/08/2024, 09:21 - David: <Media omitted>
12/08/2024, 09:22 - David: 75°F and sunny all weekend! Perfect beach weather ☀️😎
12/08/2024, 09:25 - Maya: Amazing! I put together a quick draft of our itinerary:
- 8:00 AM: Meet at the central coffee shop
- 10:30 AM: Coastal hiking trail (approx 2 hours)
- 1:00 PM: Seafood lunch by the bay
- 3:30 PM: Check-in at the beach cottage & relax
- 7:00 PM: Sunset bonfire & BBQ 🍢🔥
12/08/2024, 09:27 - Sarah: That looks super well planned Maya! Love the bonfire plan.
12/08/2024, 09:29 - Alex: Here is the Airbnb cottage address:
https://maps.google.com/?q=Seaside+Cottage+Pacific+Grove
12/08/2024, 09:30 - Alex: Booking confirmation attached below:
12/08/2024, 09:31 - Alex: Cottage_Booking_Confirmation.pdf (file attached)
12/08/2024, 09:35 - David: I will bring the portable grill and bluetooth speaker 🎶
12/08/2024, 09:36 - Maya: Perfect! I'll get marinades and veggie skewers.
12/08/2024, 09:40 - Sarah: <Media omitted>
12/08/2024, 09:41 - Sarah: Look at this trail view from last year, we definitely need cameras!
12/08/2024, 10:02 - Alex: Who is picking up the snacks?
12/08/2024, 10:05 - David: <Media omitted>
12/08/2024, 10:06 - David: Already stocked up on chips, soda and s'mores kit!
12/08/2024, 10:15 - Maya: You're the best Dave! 🙌
13/08/2024, 08:00 - Sarah: Good morning team! See you all at the coffee spot in 30 mins ☕
13/08/2024, 08:10 - Alex: On my way! Traffic is light.
13/08/2024, 08:15 - David: <Media omitted>
13/08/2024, 08:16 - David: Got a table outside by the fountain.
13/08/2024, 08:22 - Maya: Running 5 mins behind, ordering my latte ahead on the app!`,
  },
  {
    id: 'one-on-one',
    name: 'Sarah & Alex (1-on-1) ☕',
    description: 'Two participants, multiline updates, voice note placeholders, and links',
    icon: 'User',
    filename: 'WhatsApp Chat with Sarah Jenkins.txt',
    content: `[15/09/2024, 10:12:04 AM] Messages and calls are end-to-end encrypted.
[15/09/2024, 10:14:15 AM] Sarah: Hey Alex! Are you free for a quick coffee catch-up later this afternoon?
[15/09/2024, 10:16:30 AM] Alex: Hey Sarah! Yes, I just wrapped up my morning design sprint. How about 3:30 PM at Café Nero?
[15/09/2024, 10:17:10 AM] Sarah: 3:30 PM is perfect!
[15/09/2024, 10:17:45 AM] Sarah: By the way, did you get a chance to review the typography guidelines draft I shared yesterday?
[15/09/2024, 10:20:05 AM] Alex: Yes! I left a few comments on page 4.
Overall the contrast ratio and optical spacing rules look super clean.
Here is the link in case you need it:
https://design-system.internal.dev/guidelines/typography
[15/09/2024, 10:22:18 AM] Sarah: <Media omitted>
[15/09/2024, 10:23:00 AM] Sarah: Here is a quick voice note explaining the decision behind the font step ratio:
[15/09/2024, 10:23:45 AM] Sarah: audio omitted
[15/09/2024, 10:28:10 AM] Alex: That makes total sense now! The 1.25 Major Third scale keeps the headings balanced without overwhelming the body copy.
[15/09/2024, 15:25:30 PM] Sarah: Just arrived and found a nice quiet booth near the window 🌿
[15/09/2024, 15:28:12 PM] Alex: Walking in now! See you in a second.`,
  },
  {
    id: 'developer-sync',
    name: 'Engineers Sync 💻',
    description: 'Code discussions, system events, deleted messages, attachments, and iOS format',
    icon: 'Code',
    filename: 'WhatsApp Chat - Frontend Core Team.txt',
    content: `[20/10/2024, 14:02:11] Messages and calls are end-to-end encrypted.
[20/10/2024, 14:05:00] Elena: Hey team, the v2.4 deployment just completed successfully in staging! 🚀
[20/10/2024, 14:06:22] Marcus: Awesome job Elena. Did the bundle size optimization pass the budget check?
[20/10/2024, 14:07:45] Elena: Yes! We shaved off 145KB by virtualizing the heavy list components and tree-shaking unused icons.
[20/10/2024, 14:08:12] Liam: <Media omitted>
[20/10/2024, 14:08:50] Liam: Performance score jumped from 82 to 98 on Lighthouse! 📈
[20/10/2024, 14:10:05] Marcus: This message was deleted
[20/10/2024, 14:11:30] Marcus: Sorry posted in wrong channel. Here is the updated PR:
https://github.com/org/client-core/pull/842
[20/10/2024, 14:15:10] Elena: Reviewing it right now.
[20/10/2024, 14:22:35] Elena: Architecture looks solid. Approved and merged!
[20/10/2024, 14:25:00] Liam: Thanks everyone, great sprint! 🎉`,
  },
];
