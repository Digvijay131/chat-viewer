import {
  ChatMessage,
  ChatParticipant,
  ChatStatistics,
  HourlyActivity,
  DailyActivity,
  MonthlyActivity,
  EmojiStat,
} from '../types/chat';

// Regex for extracting common emojis
const EMOJI_REGEX = /(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|[\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|[\ud83c[\ude32-\ude3a]|[\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|[\ud83c\udca0-\udcff]|[\ud83d\udc00-\udfff]|[\ud83e\udc00-\udfff])/g;

// URL detector
const URL_REGEX = /https?:\/\/[^\s]+|www\.[^\s]+/gi;

export function calculateChatStats(
  messages: ChatMessage[],
  participants: ChatParticipant[]
): ChatStatistics {
  if (messages.length === 0) {
    return {
      totalMessages: 0,
      totalWords: 0,
      mediaCount: 0,
      deletedCount: 0,
      systemMessageCount: 0,
      linkCount: 0,
      participantCount: participants.length,
      firstMessageDate: null,
      lastMessageDate: null,
      durationDays: 0,
      mostActiveParticipant: null,
      participants,
      hourlyActivity: Array.from({ length: 24 }, (_, i) => ({ hour: i, count: 0 })),
      dailyActivity: [
        { dayOfWeek: 0, dayName: 'Sun', count: 0 },
        { dayOfWeek: 1, dayName: 'Mon', count: 0 },
        { dayOfWeek: 2, dayName: 'Tue', count: 0 },
        { dayOfWeek: 3, dayName: 'Wed', count: 0 },
        { dayOfWeek: 4, dayName: 'Thu', count: 0 },
        { dayOfWeek: 5, dayName: 'Fri', count: 0 },
        { dayOfWeek: 6, dayName: 'Sat', count: 0 },
      ],
      monthlyActivity: [],
      topEmojis: [],
    };
  }

  let totalWords = 0;
  let mediaCount = 0;
  let deletedCount = 0;
  let systemMessageCount = 0;
  let linkCount = 0;

  const hourlyCounts = new Array(24).fill(0);
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const dailyCounts = new Array(7).fill(0);
  const monthlyMap = new Map<string, { label: string; count: number }>();
  const emojiMap = new Map<string, number>();

  let firstTimestamp = messages[0].timestamp;
  let lastTimestamp = messages[0].timestamp;

  for (const msg of messages) {
    firstTimestamp = Math.min(firstTimestamp, msg.timestamp);
    lastTimestamp = Math.max(lastTimestamp, msg.timestamp);

    if (msg.isSystemMessage) {
      systemMessageCount++;
      continue;
    }

    if (msg.isMedia) mediaCount++;
    if (msg.isDeleted) deletedCount++;

    // URLs
    const urls = msg.content.match(URL_REGEX);
    if (urls) linkCount += urls.length;

    // Words
    const words = msg.content.trim().split(/\s+/).filter(Boolean);
    totalWords += words.length;

    // Time & Date stats
    const d = new Date(msg.timestamp);
    if (!isNaN(d.getTime())) {
      const hour = d.getHours();
      hourlyCounts[hour]++;

      const dayOfWeek = d.getDay();
      dailyCounts[dayOfWeek]++;

      const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const monthLabel = `${monthNamesShort[d.getMonth()]} ${d.getFullYear()}`;

      const existingMonth = monthlyMap.get(monthKey);
      if (existingMonth) {
        existingMonth.count++;
      } else {
        monthlyMap.set(monthKey, { label: monthLabel, count: 1 });
      }
    }

    // Emojis
    const emojis = msg.content.match(EMOJI_REGEX);
    if (emojis) {
      for (const emoji of emojis) {
        emojiMap.set(emoji, (emojiMap.get(emoji) || 0) + 1);
      }
    }
  }

  const hourlyActivity: HourlyActivity[] = hourlyCounts.map((count, hour) => ({
    hour,
    count,
  }));

  const dailyActivity: DailyActivity[] = dailyCounts.map((count, idx) => ({
    dayOfWeek: idx,
    dayName: dayNames[idx],
    count,
  }));

  const monthlyActivity: MonthlyActivity[] = Array.from(monthlyMap.entries())
    .sort(([keyA], [keyB]) => keyA.localeCompare(keyB))
    .map(([monthKey, val]) => ({
      monthKey,
      label: val.label,
      count: val.count,
    }));

  const topEmojis: EmojiStat[] = Array.from(emojiMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([emoji, count]) => ({ emoji, count }));

  const firstMessageDate = new Date(firstTimestamp);
  const lastMessageDate = new Date(lastTimestamp);
  const durationMs = Math.max(0, lastTimestamp - firstTimestamp);
  const durationDays = Math.max(1, Math.round(durationMs / (1000 * 60 * 60 * 24)));

  const mostActive = participants.length > 0 ? participants[0] : null;

  return {
    totalMessages: messages.length,
    totalWords,
    mediaCount,
    deletedCount,
    systemMessageCount,
    linkCount,
    participantCount: participants.length,
    firstMessageDate,
    lastMessageDate,
    durationDays,
    mostActiveParticipant: mostActive
      ? {
          name: mostActive.name,
          count: mostActive.messageCount,
          percentage: mostActive.percentage,
        }
      : null,
    participants,
    hourlyActivity,
    dailyActivity,
    monthlyActivity,
    topEmojis,
  };
}
