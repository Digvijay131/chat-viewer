import {
  ChatMessage,
  ChatParticipant,
  ChatExportData,
  ParseResult,
  MessageType,
  MediaDetails,
} from '../types/chat';
import { calculateChatStats } from './chatStats';

// Distinct, vibrant WhatsApp-like participant colors
const PARTICIPANT_COLORS = [
  '#00a884', // WhatsApp teal
  '#008069', // Deep teal
  '#1f71eb', // Blue
  '#b336a1', // Magenta / Purple
  '#df5b21', // Orange / Coral
  '#7b4397', // Deep Violet
  '#128c7e', // Emerald
  '#c2410c', // Rust / Amber
  '#0891b2', // Cyan
  '#4f46e5', // Indigo
  '#db2777', // Pink
  '#ca8a04', // Golden Amber
  '#059669', // Mint
  '#9333ea', // Electric Purple
  '#e11d48', // Crimson
];

// Clean invisible control chars that WhatsApp exports frequently contain
export function cleanUnicode(str: string): string {
  return str
    .replace(/[\u200E\u200F\u202A-\u202E\uFEFF]/g, '') // LTR, RTL, zero-width BOM
    .replace(/[\u202F\u00A0]/g, ' ') // Narrow and standard non-breaking spaces to space
    .trim();
}

interface ParsedHeader {
  rawDate: string;
  rawTime: string;
  rawRemainder: string;
  formatType: string;
}

// Check if a line starts a new WhatsApp message header
export function matchMessageHeader(line: string): ParsedHeader | null {
  const sanitized = cleanUnicode(line);
  if (!sanitized) return null;

  // Format 1: Bracketed style -> [12/08/2024, 10:32:15 PM] Sender: Message or [12.08.24, 22:32:15] Sender: Message
  const bracketMatch = sanitized.match(
    /^\[(\d{1,4}[/\.\-\s]\d{1,2}[/\.\-\s]\d{1,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?(?:[ ]*[ap]\.?m\.?)?)\]\s*(.*)$/i
  );
  if (bracketMatch) {
    return {
      rawDate: bracketMatch[1].trim(),
      rawTime: bracketMatch[2].trim(),
      rawRemainder: bracketMatch[3],
      formatType: 'Bracketed (iOS/macOS)',
    };
  }

  // Format 2: Standard Android/Web style with hyphen -> 12/08/2024, 10:32 pm - Sender: Message or 12.08.2024, 22:32 - Sender: Message
  const standardMatch = sanitized.match(
    /^(\d{1,4}[/\.\-\s]\d{1,2}[/\.\-\s]\d{1,4}),?\s+(\d{1,2}:\d{2}(?::\d{2})?(?:[ ]*[ap]\.?m\.?)?)\s*[-–—]\s*(.*)$/i
  );
  if (standardMatch) {
    return {
      rawDate: standardMatch[1].trim(),
      rawTime: standardMatch[2].trim(),
      rawRemainder: standardMatch[3],
      formatType: 'Standard (Android/Web)',
    };
  }

  // Format 3: No comma or alternative delimiter -> 2024-08-12 10:32:15: Sender: Message
  const altMatch = sanitized.match(
    /^(\d{4}[-/.]\d{1,2}[-/.]\d{1,2})\s+(\d{1,2}:\d{2}(?::\d{2})?(?:[ ]*[ap]\.?m\.?)?)\s*[-–—:]\s*(.*)$/i
  );
  if (altMatch) {
    return {
      rawDate: altMatch[1].trim(),
      rawTime: altMatch[2].trim(),
      rawRemainder: altMatch[3],
      formatType: 'ISO/Alternate',
    };
  }

  return null;
}

// Detect Date Order (DMY vs MDY vs YMD) from a sample of raw date strings
function deduceDateOrder(rawDates: string[]): 'DMY' | 'MDY' | 'YMD' {
  let hasDayGreaterThan12First = false;
  let hasDayGreaterThan12Second = false;
  let startsWith4Digits = false;

  for (const dateStr of rawDates) {
    const parts = dateStr.split(/[/.\-\s]+/).filter(Boolean).map(Number);
    if (parts.length >= 3) {
      if (parts[0] > 1000) {
        startsWith4Digits = true;
        break;
      }
      if (parts[0] > 12) {
        hasDayGreaterThan12First = true; // First number is Day (e.g. 24/05/2023)
      }
      if (parts[1] > 12) {
        hasDayGreaterThan12Second = true; // Second number is Day (e.g. 05/24/2023)
      }
    }
  }

  if (startsWith4Digits) return 'YMD';
  if (hasDayGreaterThan12First) return 'DMY';
  if (hasDayGreaterThan12Second) return 'MDY';
  // Default to DMY (most common WhatsApp global export format)
  return 'DMY';
}

// Parse Date components into Date object
function parseDateTime(
  rawDate: string,
  rawTime: string,
  dateOrder: 'DMY' | 'MDY' | 'YMD'
): { dateObj: Date; dateStr: string; displayDate: string; timeStr: string } {
  const dateParts = rawDate.split(/[/.\-\s]+/).filter(Boolean).map(Number);
  let year = 2024;
  let month = 1;
  let day = 1;

  if (dateParts.length >= 3) {
    if (dateOrder === 'YMD') {
      year = dateParts[0];
      month = dateParts[1];
      day = dateParts[2];
    } else if (dateOrder === 'MDY') {
      month = dateParts[0];
      day = dateParts[1];
      year = dateParts[2];
    } else {
      // DMY
      day = dateParts[0];
      month = dateParts[1];
      year = dateParts[2];
    }

    // Two-digit year resolution (e.g. 24 -> 2024, 99 -> 1999)
    if (year < 100) {
      year = year < 70 ? 2000 + year : 1900 + year;
    }
  }

  // Parse time
  let hours = 0;
  let minutes = 0;
  let seconds = 0;

  const isPM = /pm/i.test(rawTime);
  const isAM = /am/i.test(rawTime);
  const timeDigits = rawTime.replace(/[^\d:]/g, '').split(':').map(Number);

  if (timeDigits.length >= 2) {
    hours = timeDigits[0];
    minutes = timeDigits[1];
    if (timeDigits.length >= 3) {
      seconds = timeDigits[2];
    }

    if (isPM && hours < 12) {
      hours += 12;
    } else if (isAM && hours === 12) {
      hours = 0;
    }
  }

  const dateObj = new Date(year, Math.max(0, month - 1), day, hours, minutes, seconds);

  const formattedMonth = String(month).padStart(2, '0');
  const formattedDay = String(day).padStart(2, '0');
  const dateStr = `${year}-${formattedMonth}-${formattedDay}`;

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const displayDate = `${day} ${monthNames[Math.max(0, Math.min(11, month - 1))]} ${year}`;

  // Time string formatting
  const displayHours = hours % 12 || 12;
  const ampm = hours >= 12 ? 'PM' : 'AM';
  const displayMinutes = String(minutes).padStart(2, '0');
  const timeStr = `${displayHours}:${displayMinutes} ${ampm}`;

  return {
    dateObj: isNaN(dateObj.getTime()) ? new Date() : dateObj,
    dateStr,
    displayDate,
    timeStr,
  };
}

// Detect if message is a system message or extract sender and content
function parseSenderAndContent(remainder: string): {
  sender: string;
  content: string;
  isSystem: boolean;
} {
  const sanitized = cleanUnicode(remainder);

  // Common WhatsApp system phrases
  const systemPhrases = [
    'messages and calls are end-to-end encrypted',
    'end-to-end encrypted',
    'changed the subject to',
    'changed the group name to',
    'changed the group description',
    'changed this group\'s icon',
    'changed their phone number',
    'changed the group settings',
    'created group',
    'created this group',
    'added you',
    'you were added',
    'joined using this group\'s invite link',
    'left the group',
    'you left',
    'was removed',
    'you were removed',
    'security code changed',
    'pinned a message',
    'unpinned a message',
    'started a call',
    'missed group voice call',
    'missed group video call',
    'missed voice call',
    'missed video call',
    'disappearing messages turned on',
    'disappearing messages turned off',
  ];

  // Try finding sender with colon
  const colonIndex = sanitized.indexOf(':');
  if (colonIndex !== -1) {
    const potentialSender = sanitized.substring(0, colonIndex).trim();
    const potentialContent = sanitized.substring(colonIndex + 1).trim();

    // Ensure sender is not something like "http" or "https" and is reasonably short (< 60 chars)
    if (potentialSender.length > 0 && potentialSender.length < 60 && !potentialSender.startsWith('http')) {
      return {
        sender: potentialSender,
        content: potentialContent,
        isSystem: false,
      };
    }
  }

  // Check if it matches system message
  const lower = sanitized.toLowerCase();
  const isSystem = systemPhrases.some((phrase) => lower.includes(phrase));

  return {
    sender: 'System',
    content: sanitized,
    isSystem: true,
  };
}

// Classify message content into type and media details
function classifyMessage(content: string, isSystem: boolean): {
  type: MessageType;
  mediaDetails?: MediaDetails;
  isMedia: boolean;
  isDeleted: boolean;
} {
  if (isSystem) {
    return { type: 'system', isMedia: false, isDeleted: false };
  }

  const trimmed = content.trim();
  const lower = trimmed.toLowerCase();

  // Deleted messages
  if (
    lower === 'this message was deleted' ||
    lower === 'you deleted this message' ||
    lower.includes('message was deleted') ||
    lower.includes('deleted this message')
  ) {
    return {
      type: 'deleted',
      isMedia: false,
      isDeleted: true,
    };
  }

  // Media omitted variations
  if (
    lower.includes('<media omitted>') ||
    lower.includes('media omitted') ||
    lower.includes('(file attached)') ||
    lower.includes('image omitted') ||
    lower.includes('video omitted') ||
    lower.includes('audio omitted') ||
    lower.includes('sticker omitted') ||
    lower.includes('document omitted') ||
    lower.includes('contact card omitted') ||
    lower.includes('location omitted')
  ) {
    if (lower.includes('sticker')) {
      return {
        type: 'sticker',
        isMedia: true,
        isDeleted: false,
        mediaDetails: { mediaType: 'sticker', caption: 'Sticker' },
      };
    }
    if (lower.includes('video') || lower.includes('.mp4') || lower.includes('.mov')) {
      return {
        type: 'video',
        isMedia: true,
        isDeleted: false,
        mediaDetails: { mediaType: 'video', caption: 'Video' },
      };
    }
    if (lower.includes('audio') || lower.includes('voice') || lower.includes('.opus') || lower.includes('.mp3') || lower.includes('.m4a')) {
      return {
        type: 'audio',
        isMedia: true,
        isDeleted: false,
        mediaDetails: { mediaType: 'audio', duration: '0:14', caption: 'Voice Note' },
      };
    }
    if (lower.includes('document') || lower.includes('.pdf') || lower.includes('.doc') || lower.includes('.zip')) {
      const docName = trimmed.replace(/\(file attached\)/i, '').replace(/<|>/g, '').trim();
      return {
        type: 'document',
        isMedia: true,
        isDeleted: false,
        mediaDetails: { mediaType: 'document', filename: docName || 'Document.pdf', fileSize: '1.2 MB' },
      };
    }
    if (lower.includes('contact')) {
      return {
        type: 'contact',
        isMedia: true,
        isDeleted: false,
        mediaDetails: { mediaType: 'contact', caption: 'Contact Card' },
      };
    }
    if (lower.includes('location')) {
      return {
        type: 'location',
        isMedia: true,
        isDeleted: false,
        mediaDetails: { mediaType: 'location', caption: 'Location' },
      };
    }

    // Default media (photo/image)
    return {
      type: 'image',
      isMedia: true,
      isDeleted: false,
      mediaDetails: { mediaType: 'image', caption: 'Photo' },
    };
  }

  // Location URLs
  if (lower.includes('maps.google.com') || lower.includes('maps.apple.com') || lower.startsWith('location:')) {
    return {
      type: 'location',
      isMedia: true,
      isDeleted: false,
      mediaDetails: { mediaType: 'location', url: trimmed, caption: 'Shared Location' },
    };
  }

  // Call notifications
  if (
    lower.includes('missed voice call') ||
    lower.includes('missed video call') ||
    lower.includes('missed group call')
  ) {
    return {
      type: 'call',
      isMedia: false,
      isDeleted: false,
    };
  }

  return {
    type: 'text',
    isMedia: false,
    isDeleted: false,
  };
}

// Assign colors and calculate stats for participants
export function processParticipants(
  messages: ChatMessage[],
  preferredMeSender?: string
): { participants: ChatParticipant[]; mySender: string; isGroupChat: boolean } {
  const senderCounts: Record<string, { count: number; media: number; first: number; last: number }> = {};
  let totalNonSystemMessages = 0;

  for (const msg of messages) {
    if (msg.isSystemMessage || !msg.sender || msg.sender === 'System') continue;

    totalNonSystemMessages++;
    if (!senderCounts[msg.sender]) {
      senderCounts[msg.sender] = {
        count: 0,
        media: 0,
        first: msg.timestamp,
        last: msg.timestamp,
      };
    }

    senderCounts[msg.sender].count++;
    if (msg.isMedia) senderCounts[msg.sender].media++;
    senderCounts[msg.sender].last = Math.max(senderCounts[msg.sender].last, msg.timestamp);
    senderCounts[msg.sender].first = Math.min(senderCounts[msg.sender].first, msg.timestamp);
  }

  const uniqueSenders = Object.keys(senderCounts);
  const isGroupChat = uniqueSenders.length > 2;

  // Determine "Me" sender
  let mySender = preferredMeSender || '';
  if (!mySender || !uniqueSenders.includes(mySender)) {
    // Check common "Me" aliases in exports
    const meCandidate = uniqueSenders.find(
      (s) =>
        s.toLowerCase() === 'you' ||
        s.toLowerCase() === 'me' ||
        s.toLowerCase().includes('(you)') ||
        s.toLowerCase() === 'myself'
    );

    if (meCandidate) {
      mySender = meCandidate;
    } else if (uniqueSenders.length === 2) {
      // In 1-on-1 chats, default to the second sender or first if only 1
      mySender = uniqueSenders[1] || uniqueSenders[0] || '';
    } else if (uniqueSenders.length > 0) {
      // Pick most frequent sender or first sender
      mySender = uniqueSenders[0];
    }
  }

  // Assign colors consistently
  const participants: ChatParticipant[] = uniqueSenders.map((name, idx) => {
    const data = senderCounts[name];
    const percentage = totalNonSystemMessages > 0 ? (data.count / totalNonSystemMessages) * 100 : 0;
    return {
      name,
      messageCount: data.count,
      mediaCount: data.media,
      percentage: Number(percentage.toFixed(1)),
      firstActive: data.first,
      lastActive: data.last,
      color: PARTICIPANT_COLORS[idx % PARTICIPANT_COLORS.length],
    };
  });

  // Sort participants by message count descending
  participants.sort((a, b) => b.messageCount - a.messageCount);

  return { participants, mySender, isGroupChat };
}

// Main parser function
export function parseWhatsAppChat(
  rawText: string,
  fileName: string = 'WhatsApp Chat.txt',
  preferredMe?: string
): ParseResult {
  if (!rawText || !rawText.trim()) {
    return {
      success: false,
      error: 'The uploaded file is empty. Please select a valid WhatsApp exported .txt file.',
      rawSample: '',
    };
  }

  const lines = rawText.split(/\r?\n/);
  if (lines.length === 0) {
    return {
      success: false,
      error: 'No text content found in file.',
      rawSample: '',
    };
  }

  // 1. Gather all line headers to sample date formats and test validity
  const sampleDates: string[] = [];
  let detectedFormatName = 'Unknown Format';
  let firstHeaderIndex = -1;

  for (let i = 0; i < Math.min(lines.length, 100); i++) {
    const match = matchMessageHeader(lines[i]);
    if (match) {
      sampleDates.push(match.rawDate);
      if (firstHeaderIndex === -1) {
        firstHeaderIndex = i;
        detectedFormatName = match.formatType;
      }
    }
  }

  if (firstHeaderIndex === -1) {
    // Show sample of first 5 non-empty lines for debugging
    const sampleSnippet = lines.slice(0, 8).filter(Boolean).join('\n');
    return {
      success: false,
      error: 'Unable to recognize this WhatsApp export format. Please ensure the file was exported directly from WhatsApp as text.',
      rawSample: sampleSnippet,
    };
  }

  const dateOrder = deduceDateOrder(sampleDates);

  // 2. Parse all messages, properly combining multiline messages
  interface RawMessageAcc {
    rawDate: string;
    rawTime: string;
    remainder: string;
    lines: string[];
    lineIndex: number;
  }

  const parsedBlocks: RawMessageAcc[] = [];
  let currentBlock: RawMessageAcc | null = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const header = matchMessageHeader(line);

    if (header) {
      // New message started
      if (currentBlock) {
        parsedBlocks.push(currentBlock);
      }
      currentBlock = {
        rawDate: header.rawDate,
        rawTime: header.rawTime,
        remainder: header.rawRemainder,
        lines: [header.rawRemainder],
        lineIndex: i,
      };
    } else {
      // Continuation of previous multiline message
      if (currentBlock) {
        currentBlock.lines.push(line);
      }
    }
  }

  if (currentBlock) {
    parsedBlocks.push(currentBlock);
  }

  if (parsedBlocks.length === 0) {
    return {
      success: false,
      error: 'No messages could be parsed from the file.',
      rawSample: lines.slice(0, 5).join('\n'),
    };
  }

  // 3. Convert parsed blocks into normalized ChatMessage objects
  const rawMessages: ChatMessage[] = [];

  parsedBlocks.forEach((block, idx) => {
    const { dateObj, dateStr, displayDate, timeStr } = parseDateTime(
      block.rawDate,
      block.rawTime,
      dateOrder
    );

    const fullContentString = block.lines.join('\n').trim();
    const { sender, content, isSystem } = parseSenderAndContent(fullContentString);
    const { type, mediaDetails, isMedia, isDeleted } = classifyMessage(content, isSystem);

    rawMessages.push({
      id: `msg-${idx + 1}`,
      rawTimestamp: `${block.rawDate} ${block.rawTime}`,
      timestamp: dateObj.getTime(),
      dateStr,
      displayDate,
      timeStr,
      sender,
      content,
      type,
      mediaDetails,
      isSystemMessage: isSystem,
      isMedia,
      isDeleted,
      isOutgoing: false, // Will be set after sender mapping
      lineIndex: block.lineIndex,
    });
  });

  // Sort messages chronologically by timestamp
  rawMessages.sort((a, b) => a.timestamp - b.timestamp);

  // 4. Process participants & determine "Me"
  const { participants, mySender, isGroupChat } = processParticipants(rawMessages, preferredMe);

  // 5. Update isOutgoing flag on all messages
  for (const msg of rawMessages) {
    msg.isOutgoing = !msg.isSystemMessage && Boolean(mySender) && msg.sender.toLowerCase() === mySender.toLowerCase();
  }

  // 6. Deduce Chat Title
  let title = fileName.replace(/WhatsApp Chat with /i, '').replace(/WhatsApp Chat - /i, '').replace(/\.txt$/i, '');
  if (title === 'WhatsApp Chat' || title === 'chat' || !title) {
    if (isGroupChat) {
      title = 'WhatsApp Group Chat';
    } else if (participants.length > 0) {
      // Name of the other participant in 1-on-1
      const otherPerson = participants.find((p) => p.name.toLowerCase() !== mySender.toLowerCase());
      title = otherPerson ? otherPerson.name : participants[0].name;
    } else {
      title = 'WhatsApp Conversation';
    }
  }

  // 7. Calculate comprehensive statistics
  const stats = calculateChatStats(rawMessages, participants);

  const exportData: ChatExportData = {
    title,
    isGroupChat,
    detectedFormat: `${detectedFormatName} (${dateOrder})`,
    fileName,
    fileSizeBytes: new Blob([rawText]).size,
    messages: rawMessages,
    participants,
    mySenderName: mySender,
    stats,
  };

  return {
    success: true,
    data: exportData,
    detectedFormatName,
  };
}
