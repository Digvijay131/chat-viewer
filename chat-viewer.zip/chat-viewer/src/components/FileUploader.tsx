import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  MessageSquare,
  Users,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { SAMPLE_CHATS, SampleChatPreset } from '../utils/sampleChats';
import { ThemeMode } from '../types/chat';

interface FileUploaderProps {
  onFileLoaded: (content: string, fileName: string) => void;
  onSelectSample: (sample: SampleChatPreset) => void;
  isParsing: boolean;
  parseProgress?: number;
  theme: ThemeMode;
  onSetTheme: (theme: ThemeMode) => void;
  isDark?: boolean;
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  onFileLoaded,
  onSelectSample,
  isParsing,
  parseProgress = 0,
  theme,
  onSetTheme,
  isDark = false,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedFileMeta, setSelectedFileMeta] = useState<{ name: string; size: string } | null>(
    null
  );
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const handleFile = (file: File) => {
    setUploadError(null);

    // Validate extension
    if (!file.name.toLowerCase().endsWith('.txt')) {
      setUploadError('Please select a valid .txt file exported from WhatsApp.');
      return;
    }

    // Record meta
    setSelectedFileMeta({
      name: file.name,
      size: formatFileSize(file.size),
    });

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content || !content.trim()) {
        setUploadError('The selected file is empty. Please select a valid WhatsApp exported .txt file.');
        return;
      }
      onFileLoaded(content, file.name);
    };

    reader.onerror = () => {
      setUploadError('Failed to read file. Please try again.');
    };

    reader.readAsText(file, 'UTF-8');
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFile(e.target.files[0]);
    }
  };

  return (
    <div
      id="file-uploader-screen"
      className={`min-h-screen flex flex-col justify-between transition-colors ${
        isDark ? 'bg-[#0b141a] text-[#e9edef]' : 'bg-[#f0f2f5] text-[#111b21]'
      }`}
    >
      {/* Top Navbar */}
      <header
        className={`px-4 sm:px-8 py-4 flex items-center justify-between border-b ${
          isDark ? 'bg-[#111b21] border-[#222e35]' : 'bg-[#ffffff] border-[#e9edef]'
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#008069] to-[#00a884] text-white flex items-center justify-center shadow-md">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">Chat Viewer</h1>
            <p className="text-xs text-[#8696a0]">WhatsApp Export Reader</p>
          </div>
        </div>

        {/* Theme toggle in header */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="uploader-theme-toggle"
            onClick={() => onSetTheme(isDark ? 'light' : 'dark')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border flex items-center gap-1.5 transition-colors cursor-pointer ${
              isDark
                ? 'bg-[#202c33] border-[#2a3942] hover:bg-[#2a3942] text-[#d1d7db]'
                : 'bg-[#f8fafc] border-[#cbd5e1] hover:bg-[#e2e8f0] text-[#475569]'
            }`}
          >
            {isDark ? '☀️ Light Mode' : '🌙 Dark Mode'}
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col items-center justify-center p-4 sm:p-8 max-w-4xl mx-auto w-full">
        <div className="text-center max-w-xl mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#00a884]/15 text-[#00a884] mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Fast, 100% Client-Side WhatsApp Reader</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
            Chat Viewer
          </h2>
          <p className="text-sm sm:text-base text-[#667781] dark:text-[#8696a0] mt-2">
            View your exported WhatsApp chats in a familiar interface.
          </p>
        </div>

        {/* Drag & Drop Card */}
        <div
          id="drop-zone-container"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onClick={() => fileInputRef.current?.click()}
          className={`w-full max-w-2xl rounded-2xl border-2 border-dashed p-8 sm:p-12 text-center transition-all cursor-pointer shadow-lg relative overflow-hidden ${
            isDragOver
              ? 'border-[#00a884] bg-[#00a884]/10 scale-[1.01]'
              : isDark
              ? 'bg-[#111b21] border-[#2a3942] hover:border-[#00a884]/70 hover:bg-[#182229]'
              : 'bg-[#ffffff] border-[#cbd5e1] hover:border-[#00a884]/70 hover:bg-[#f8fafc]'
          }`}
        >
          <input
            ref={fileInputRef}
            id="file-input-hidden"
            type="file"
            accept=".txt"
            onChange={handleInputChange}
            className="hidden"
          />

          {isParsing ? (
            <div className="flex flex-col items-center justify-center py-6 space-y-4">
              <div className="w-14 h-14 rounded-full border-4 border-[#00a884]/30 border-t-[#00a884] animate-spin" />
              <div className="text-base font-semibold">Parsing conversation...</div>
              <p className="text-xs text-[#8696a0]">
                Extracting messages, dates, media placeholders, and participant analytics
              </p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center space-y-4">
              <div
                className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-inner transition-transform group-hover:scale-110 ${
                  isDark ? 'bg-[#202c33] text-[#00a884]' : 'bg-[#e7f8f5] text-[#00a884]'
                }`}
              >
                <UploadCloud className="w-8 h-8" />
              </div>

              <div>
                <p className="text-base sm:text-lg font-bold">
                  Drag and drop your exported <span className="text-[#00a884]">.txt</span> chat here
                </p>
                <p className="text-xs sm:text-sm text-[#8696a0] mt-1">
                  Supports Android, iPhone / iOS, and Web export formats
                </p>
              </div>

              <button
                type="button"
                id="btn-choose-file"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                className="px-6 py-2.5 rounded-xl bg-[#00a884] hover:bg-[#008069] text-white text-sm font-semibold transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-2"
              >
                <FileText className="w-4 h-4" />
                <span>Choose TXT File</span>
              </button>

              {selectedFileMeta && (
                <div
                  className={`mt-2 px-3 py-1.5 rounded-lg text-xs flex items-center gap-2 border ${
                    isDark
                      ? 'bg-[#202c33] border-[#2a3942] text-[#e9edef]'
                      : 'bg-[#f0f2f5] border-[#e2e8f0] text-[#111b21]'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00a884]" />
                  <span className="font-semibold">{selectedFileMeta.name}</span>
                  <span className="text-[#8696a0]">({selectedFileMeta.size})</span>
                </div>
              )}

              {uploadError && (
                <div className="mt-2 px-3.5 py-2 rounded-xl text-xs flex items-center gap-2 bg-red-500/10 border border-red-500/30 text-red-500 text-left max-w-md">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{uploadError}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Try Sample Chats Section */}
        <div className="w-full max-w-2xl mt-8">
          <div className="flex items-center justify-between mb-3 px-1">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>Or explore with a sample chat</span>
            </h3>
            <span className="text-[11px] text-[#8696a0]">1-Click Instant Demo</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {SAMPLE_CHATS.map((sample) => (
              <button
                key={sample.id}
                type="button"
                id={`btn-sample-${sample.id}`}
                onClick={() => onSelectSample(sample)}
                className={`p-3.5 rounded-xl border text-left transition-all hover:scale-[1.02] active:scale-[0.99] group cursor-pointer ${
                  isDark
                    ? 'bg-[#111b21] border-[#222e35] hover:border-[#00a884] hover:bg-[#182229]'
                    : 'bg-[#ffffff] border-[#e2e8f0] hover:border-[#00a884] hover:bg-[#f8fafc]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-sm truncate">{sample.name}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#8696a0] group-hover:text-[#00a884] group-hover:translate-x-0.5 transition-all" />
                </div>
                <p className="text-xs text-[#8696a0] line-clamp-2 leading-relaxed">
                  {sample.description}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Privacy Notice Card */}
        <div
          className={`w-full max-w-2xl mt-6 p-4 rounded-xl border flex items-start gap-3 ${
            isDark
              ? 'bg-[#111b21] border-emerald-500/20 text-emerald-300'
              : 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
          }`}
        >
          <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0 mt-0.5">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              100% Client-Side Privacy
            </div>
            <p className="text-xs text-[#667781] dark:text-[#8696a0] mt-0.5 leading-relaxed">
              Your chat is processed locally in your browser and is not uploaded to a server.
            </p>
          </div>
        </div>
      </main>

      {/* Footer Info */}
      <footer
        className={`py-4 px-6 text-center text-xs border-t ${
          isDark ? 'bg-[#111b21] border-[#222e35] text-[#8696a0]' : 'bg-[#ffffff] border-[#e9edef] text-[#8696a0]'
        }`}
      >
        <span>Chat Viewer — Clean, high-performance WhatsApp export reader</span>
      </footer>
    </div>
  );
};
