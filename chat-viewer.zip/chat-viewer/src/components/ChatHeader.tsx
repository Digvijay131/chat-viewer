import React from 'react';
import {
  ArrowLeft,
  Search,
  Users,
  BarChart3,
  Settings as SettingsIcon,
  ChevronsUp,
  ChevronsDown,
  User,
} from 'lucide-react';
import { ChatExportData } from '../types/chat';

interface ChatHeaderProps {
  chatData: ChatExportData;
  onBack: () => void;
  onOpenSearch: () => void;
  onOpenParticipants: () => void;
  onOpenStats: () => void;
  onOpenSettings: () => void;
  onScrollToTop: () => void;
  onScrollToBottom: () => void;
  isSearchOpen: boolean;
  isDark?: boolean;
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({
  chatData,
  onBack,
  onOpenSearch,
  onOpenParticipants,
  onOpenStats,
  onOpenSettings,
  onScrollToTop,
  onScrollToBottom,
  isSearchOpen,
  isDark = false,
}) => {
  // Generate participant subtitle
  const subtitleText = chatData.isGroupChat
    ? `${chatData.participants.length} participants (${chatData.participants
        .slice(0, 3)
        .map((p) => p.name)
        .join(', ')}${chatData.participants.length > 3 ? '...' : ''})`
    : `${chatData.messages.length} messages • tap for stats`;

  return (
    <header
      id="whatsapp-chat-header"
      className={`h-16 px-2 sm:px-4 flex items-center justify-between shadow-xs z-20 border-b select-none transition-colors ${
        isDark
          ? 'bg-[#202c33] border-[#2a3942] text-[#e9edef]'
          : 'bg-[#f0f2f5] border-[#e9edef] text-[#111b21]'
      }`}
    >
      {/* Left section: Back + Avatar + Titles */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
        <button
          type="button"
          id="btn-upload-another"
          onClick={onBack}
          title="Upload another chat"
          className={`p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors cursor-pointer text-[#54656f] dark:text-[#aebac1]`}
          aria-label="Upload another chat"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        {/* Avatar */}
        <div
          onClick={onOpenParticipants}
          className="relative w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm text-white shrink-0 cursor-pointer shadow-xs overflow-hidden transition-transform active:scale-95"
          style={{
            background: chatData.isGroupChat
              ? 'linear-gradient(135deg, #00a884, #008069)'
              : 'linear-gradient(135deg, #1f71eb, #128c7e)',
          }}
          title="View Participants"
        >
          {chatData.isGroupChat ? (
            <Users className="w-5 h-5" />
          ) : (
            <span>
              {chatData.title
                .split(' ')
                .map((w) => w[0])
                .join('')
                .slice(0, 2)
                .toUpperCase() || <User className="w-5 h-5" />}
            </span>
          )}
        </div>

        {/* Chat info (Clickable to open stats/participants) */}
        <div
          onClick={onOpenParticipants}
          className="min-w-0 flex-1 cursor-pointer group"
          title="View details & participants"
        >
          <h1 className="text-sm sm:text-base font-semibold truncate leading-tight group-hover:text-[#00a884] transition-colors">
            {chatData.title}
          </h1>
          <p className="text-xs text-[#667781] dark:text-[#8696a0] truncate leading-tight mt-0.5">
            {subtitleText}
          </p>
        </div>
      </div>

      {/* Right action icons */}
      <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
        {/* Quick jump up/down */}
        <button
          type="button"
          id="btn-jump-oldest"
          onClick={onScrollToTop}
          title="Jump to oldest message"
          className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors text-[#54656f] dark:text-[#aebac1] hidden md:flex items-center justify-center cursor-pointer"
          aria-label="Jump to oldest message"
        >
          <ChevronsUp className="w-4 h-4" />
        </button>

        <button
          type="button"
          id="btn-jump-newest"
          onClick={onScrollToBottom}
          title="Jump to latest message"
          className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors text-[#54656f] dark:text-[#aebac1] hidden md:flex items-center justify-center cursor-pointer"
          aria-label="Jump to latest message"
        >
          <ChevronsDown className="w-4 h-4" />
        </button>

        {/* Search */}
        <button
          type="button"
          id="btn-toggle-search"
          onClick={onOpenSearch}
          title="Search conversation (Ctrl/Cmd+F)"
          className={`p-2 rounded-full transition-colors cursor-pointer ${
            isSearchOpen
              ? 'bg-[#00a884] text-white'
              : 'hover:bg-black/5 dark:hover:bg-white/10 text-[#54656f] dark:text-[#aebac1]'
          }`}
          aria-label="Search conversation"
        >
          <Search className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Participants */}
        <button
          type="button"
          id="btn-open-participants"
          onClick={onOpenParticipants}
          title="Participants list"
          className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors text-[#54656f] dark:text-[#aebac1] cursor-pointer"
          aria-label="Participants list"
        >
          <Users className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Stats */}
        <button
          type="button"
          id="btn-open-stats"
          onClick={onOpenStats}
          title="Chat Analytics & Statistics"
          className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors text-[#54656f] dark:text-[#aebac1] cursor-pointer"
          aria-label="Chat Statistics"
        >
          <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Settings */}
        <button
          type="button"
          id="btn-open-settings"
          onClick={onOpenSettings}
          title="Settings & Me Identity"
          className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors text-[#54656f] dark:text-[#aebac1] cursor-pointer"
          aria-label="Settings"
        >
          <SettingsIcon className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>
    </header>
  );
};
