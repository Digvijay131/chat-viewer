import React, { useState } from 'react';
import {
  X,
  BarChart3,
  MessageSquare,
  Users,
  Calendar,
  Clock,
  Smile,
  FileText,
  Flame,
  Camera,
  Link as LinkIcon,
} from 'lucide-react';
import { ChatStatistics, ChatExportData } from '../types/chat';

interface StatisticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  chatData: ChatExportData;
  isDark?: boolean;
}

export const StatisticsModal: React.FC<StatisticsModalProps> = ({
  isOpen,
  onClose,
  chatData,
  isDark = false,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'activity' | 'emojis'>('overview');

  if (!isOpen) return null;

  const stats = chatData.stats;
  const maxHourlyCount = Math.max(...stats.hourlyActivity.map((h) => h.count), 1);
  const maxDailyCount = Math.max(...stats.dailyActivity.map((d) => d.count), 1);
  const maxMonthlyCount = Math.max(...stats.monthlyActivity.map((m) => m.count), 1);

  // Peak hour
  const peakHourObj = stats.hourlyActivity.reduce((prev, current) =>
    current.count > prev.count ? current : prev
  );
  const formatHour = (h: number) => {
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 || 12;
    return `${displayH} ${period}`;
  };

  // Peak day
  const peakDayObj = stats.dailyActivity.reduce((prev, current) =>
    current.count > prev.count ? current : prev
  );

  return (
    <div
      id="statistics-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="statistics-modal-container"
        className={`w-full max-w-2xl rounded-2xl shadow-2xl border flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200 ${
          isDark
            ? 'bg-[#111b21] border-[#222e35] text-[#e9edef]'
            : 'bg-white border-[#e2e8f0] text-[#111b21]'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div
          className={`px-5 py-4 flex items-center justify-between border-b ${
            isDark ? 'border-[#222e35] bg-[#202c33]' : 'border-[#e9edef] bg-[#f0f2f5]'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#00a884]/20 text-[#00a884] flex items-center justify-center">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-semibold">Chat Analytics & Statistics</h2>
              <p className="text-xs text-[#8696a0] truncate max-w-xs sm:max-w-md">
                {chatData.title}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-[#8696a0] hover:text-[#e9edef] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div
          className={`flex border-b px-4 ${
            isDark ? 'border-[#222e35] bg-[#182229]' : 'border-[#e9edef] bg-[#f8fafc]'
          }`}
        >
          <button
            type="button"
            id="tab-stats-overview"
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'overview'
                ? 'border-[#00a884] text-[#00a884]'
                : 'border-transparent text-[#8696a0] hover:text-[#e9edef]'
            }`}
          >
            Overview
          </button>
          <button
            type="button"
            id="tab-stats-activity"
            onClick={() => setActiveTab('activity')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'activity'
                ? 'border-[#00a884] text-[#00a884]'
                : 'border-transparent text-[#8696a0] hover:text-[#e9edef]'
            }`}
          >
            Activity & Times
          </button>
          <button
            type="button"
            id="tab-stats-emojis"
            onClick={() => setActiveTab('emojis')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'emojis'
                ? 'border-[#00a884] text-[#00a884]'
                : 'border-transparent text-[#8696a0] hover:text-[#e9edef]'
            }`}
          >
            Top Emojis
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* KPI Cards Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div
                  className={`p-3.5 rounded-xl border ${
                    isDark ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs text-[#8696a0] mb-1">
                    <MessageSquare className="w-3.5 h-3.5 text-[#00a884]" />
                    <span>Total Messages</span>
                  </div>
                  <div className="text-xl font-bold text-[#00a884]">
                    {stats.totalMessages.toLocaleString()}
                  </div>
                </div>

                <div
                  className={`p-3.5 rounded-xl border ${
                    isDark ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs text-[#8696a0] mb-1">
                    <Users className="w-3.5 h-3.5 text-blue-500" />
                    <span>Participants</span>
                  </div>
                  <div className="text-xl font-bold text-blue-500">
                    {stats.participantCount}
                  </div>
                </div>

                <div
                  className={`p-3.5 rounded-xl border ${
                    isDark ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs text-[#8696a0] mb-1">
                    <FileText className="w-3.5 h-3.5 text-purple-500" />
                    <span>Total Words</span>
                  </div>
                  <div className="text-xl font-bold text-purple-500">
                    {stats.totalWords.toLocaleString()}
                  </div>
                </div>

                <div
                  className={`p-3.5 rounded-xl border ${
                    isDark ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                  }`}
                >
                  <div className="flex items-center gap-1.5 text-xs text-[#8696a0] mb-1">
                    <Camera className="w-3.5 h-3.5 text-amber-500" />
                    <span>Media / Files</span>
                  </div>
                  <div className="text-xl font-bold text-amber-500">
                    {stats.mediaCount.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Date Span & Highlights */}
              <div
                className={`p-4 rounded-xl border ${
                  isDark ? 'bg-[#182229] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                }`}
              >
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] mb-3 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#00a884]" />
                  <span>Timeline Span</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
                  <div>
                    <div className="text-xs text-[#8696a0]">First Message</div>
                    <div className="font-medium mt-0.5">
                      {stats.firstMessageDate
                        ? stats.firstMessageDate.toLocaleDateString(undefined, {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                          })
                        : 'N/A'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-[#8696a0]">Last Message</div>
                    <div className="font-medium mt-0.5">
                      {stats.lastMessageDate
                        ? stats.lastMessageDate.toLocaleDateString(undefined, {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                          })
                        : 'N/A'}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-[#8696a0]">Span Duration</div>
                    <div className="font-medium mt-0.5">{stats.durationDays} days</div>
                  </div>
                </div>
              </div>

              {/* Most Active Participant & Highlights */}
              {stats.mostActiveParticipant && (
                <div
                  className={`p-4 rounded-xl border flex items-center justify-between gap-4 ${
                    isDark
                      ? 'bg-gradient-to-r from-amber-500/10 to-transparent border-amber-500/20'
                      : 'bg-gradient-to-r from-amber-50 to-orange-50/50 border-amber-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-md">
                      <Flame className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-xs text-amber-600 dark:text-amber-400 font-semibold uppercase tracking-wider">
                        Most Active Participant
                      </div>
                      <div className="text-base font-bold">{stats.mostActiveParticipant.name}</div>
                      <div className="text-xs text-[#8696a0]">
                        Sent {stats.mostActiveParticipant.count.toLocaleString()} messages (
                        {stats.mostActiveParticipant.percentage}% of chat)
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Participant breakdown */}
              <div className="space-y-3">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[#8696a0]">
                  Messages by Participant
                </h3>
                <div className="space-y-2.5">
                  {stats.participants.map((p) => (
                    <div key={p.name} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="truncate">{p.name}</span>
                        <span className="text-[#8696a0]">
                          {p.messageCount.toLocaleString()} ({p.percentage}%)
                        </span>
                      </div>
                      <div
                        className={`h-2 rounded-full overflow-hidden ${
                          isDark ? 'bg-[#202c33]' : 'bg-[#e2e8f0]'
                        }`}
                      >
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${p.percentage}%`,
                            backgroundColor: p.color,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ACTIVITY & TIMES */}
          {activeTab === 'activity' && (
            <div className="space-y-6">
              {/* Peak summary banners */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div
                  className={`p-3.5 rounded-xl border flex items-center gap-3 ${
                    isDark ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                  }`}
                >
                  <div className="w-9 h-9 rounded-full bg-[#00a884]/20 text-[#00a884] flex items-center justify-center">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-[#8696a0]">Peak Chatting Hour</div>
                    <div className="text-sm font-bold">
                      {formatHour(peakHourObj.hour)} ({peakHourObj.count} messages)
                    </div>
                  </div>
                </div>

                <div
                  className={`p-3.5 rounded-xl border flex items-center gap-3 ${
                    isDark ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                  }`}
                >
                  <div className="w-9 h-9 rounded-full bg-blue-500/20 text-blue-500 flex items-center justify-center">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-[#8696a0]">Busiest Day of Week</div>
                    <div className="text-sm font-bold">
                      {peakDayObj.dayName} ({peakDayObj.count} messages)
                    </div>
                  </div>
                </div>
              </div>

              {/* 24-Hour Activity Graph */}
              <div
                className={`p-4 rounded-xl border ${
                  isDark ? 'bg-[#182229] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                }`}
              >
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] mb-4">
                  Messages by Hour of Day (24-Hour Distribution)
                </h3>
                <div className="h-36 flex items-end gap-1 sm:gap-1.5 pt-6 pb-2">
                  {stats.hourlyActivity.map((item) => {
                    const heightPercent = Math.max((item.count / maxHourlyCount) * 100, 4);
                    const isPeak = item.hour === peakHourObj.hour && item.count > 0;
                    return (
                      <div
                        key={item.hour}
                        className="flex-1 flex flex-col items-center gap-1 group relative h-full justify-end"
                      >
                        {/* Tooltip */}
                        <div className="absolute -top-7 scale-0 group-hover:scale-100 transition-all bg-slate-900 text-white text-[10px] px-1.5 py-0.5 rounded shadow whitespace-nowrap z-20 pointer-events-none">
                          {formatHour(item.hour)}: {item.count} msgs
                        </div>

                        <div
                          className={`w-full rounded-t-sm transition-all duration-300 ${
                            isPeak
                              ? 'bg-[#00a884]'
                              : isDark
                              ? 'bg-[#2a3942] group-hover:bg-[#00a884]/70'
                              : 'bg-[#cbd5e1] group-hover:bg-[#00a884]/70'
                          }`}
                          style={{ height: `${heightPercent}%` }}
                        />
                        <span className="text-[9px] text-[#8696a0] hidden sm:block">
                          {item.hour % 6 === 0 ? `${item.hour}h` : ''}
                        </span>
                      </div>
                    );
                  })}
                </div>
                <div className="flex justify-between text-[10px] text-[#8696a0] border-t pt-1 border-[#8696a0]/20">
                  <span>12 AM (Midnight)</span>
                  <span>6 AM</span>
                  <span>12 PM (Noon)</span>
                  <span>6 PM</span>
                  <span>11 PM</span>
                </div>
              </div>

              {/* Day of Week Distribution */}
              <div
                className={`p-4 rounded-xl border ${
                  isDark ? 'bg-[#182229] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                }`}
              >
                <h3 className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] mb-3">
                  Messages by Day of Week
                </h3>
                <div className="grid grid-cols-7 gap-2 text-center">
                  {stats.dailyActivity.map((day) => {
                    const heightPercent = Math.max((day.count / maxDailyCount) * 100, 6);
                    const isPeak = day.dayName === peakDayObj.dayName && day.count > 0;
                    return (
                      <div key={day.dayName} className="flex flex-col items-center gap-1.5">
                        <div className="text-xs font-semibold">{day.dayName}</div>
                        <div
                          className={`w-full h-20 rounded-lg flex flex-col justify-end p-1 ${
                            isDark ? 'bg-[#202c33]' : 'bg-[#e2e8f0]'
                          }`}
                        >
                          <div
                            className={`w-full rounded-md transition-all duration-500 ${
                              isPeak ? 'bg-[#00a884]' : 'bg-[#00a884]/50'
                            }`}
                            style={{ height: `${heightPercent}%` }}
                          />
                        </div>
                        <div className="text-[11px] text-[#8696a0]">{day.count}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Monthly Timeline if multimonth */}
              {stats.monthlyActivity.length > 1 && (
                <div
                  className={`p-4 rounded-xl border ${
                    isDark ? 'bg-[#182229] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                  }`}
                >
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] mb-3">
                    Monthly Message Trend
                  </h3>
                  <div className="space-y-2">
                    {stats.monthlyActivity.map((month) => (
                      <div key={month.monthKey} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span>{month.label}</span>
                          <span className="text-[#8696a0]">{month.count} msgs</span>
                        </div>
                        <div
                          className={`h-2 rounded-full overflow-hidden ${
                            isDark ? 'bg-[#202c33]' : 'bg-[#e2e8f0]'
                          }`}
                        >
                          <div
                            className="h-full rounded-full bg-blue-500 transition-all duration-500"
                            style={{ width: `${(month.count / maxMonthlyCount) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: TOP EMOJIS */}
          {activeTab === 'emojis' && (
            <div className="space-y-4">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5">
                <Smile className="w-3.5 h-3.5 text-[#00a884]" />
                <span>Top Emojis Used in Conversation</span>
              </h3>

              {stats.topEmojis.length === 0 ? (
                <div
                  className={`p-8 rounded-xl text-center text-sm text-[#8696a0] border ${
                    isDark ? 'bg-[#182229] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                  }`}
                >
                  No emojis detected in this chat export.
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {stats.topEmojis.map((item, index) => (
                    <div
                      key={item.emoji}
                      className={`p-3 rounded-xl border flex items-center gap-2.5 transition-transform hover:scale-105 ${
                        isDark ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
                      }`}
                    >
                      <span className="text-2xl">{item.emoji}</span>
                      <div>
                        <div className="text-sm font-bold">{item.count}</div>
                        <div className="text-[10px] text-[#8696a0]">#{index + 1} used</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div
          className={`p-4 border-t flex justify-end ${
            isDark ? 'border-[#222e35] bg-[#182229]' : 'border-[#e9edef] bg-[#f8fafc]'
          }`}
        >
          <button
            type="button"
            id="btn-close-stats-modal"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#00a884] hover:bg-[#008069] text-white text-sm font-semibold transition-colors shadow-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
