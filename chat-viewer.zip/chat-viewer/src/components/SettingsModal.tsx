import React from 'react';
import {
  X,
  Settings as SettingsIcon,
  Sun,
  Moon,
  Monitor,
  Type,
  User,
  ShieldCheck,
  FileCheck,
} from 'lucide-react';
import { ChatParticipant, ThemeMode, FontSizeOption, ChatExportData } from '../types/chat';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  chatData: ChatExportData;
  mySenderName: string;
  onSetMySender: (name: string) => void;
  theme: ThemeMode;
  onSetTheme: (theme: ThemeMode) => void;
  fontSize: FontSizeOption;
  onSetFontSize: (size: FontSizeOption) => void;
  isDark?: boolean;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  chatData,
  mySenderName,
  onSetMySender,
  theme,
  onSetTheme,
  fontSize,
  onSetFontSize,
  isDark = false,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="settings-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="settings-modal-container"
        className={`w-full max-w-lg rounded-2xl shadow-2xl border flex flex-col max-h-[85vh] overflow-hidden animate-in zoom-in-95 duration-200 ${
          isDark
            ? 'bg-[#111b21] border-[#222e35] text-[#e9edef]'
            : 'bg-white border-[#e2e8f0] text-[#111b21]'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div
          className={`px-5 py-4 flex items-center justify-between border-b ${
            isDark ? 'border-[#222e35] bg-[#202c33]' : 'border-[#e9edef] bg-[#f0f2f5]'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#00a884]/20 text-[#00a884] flex items-center justify-center">
              <SettingsIcon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold">Viewer Settings</h2>
              <p className="text-xs text-[#8696a0]">Customize your chat experience</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-[#8696a0] hover:text-[#e9edef] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* 1. Who is Me / Perspective */}
          <div className="space-y-2">
            <label
              htmlFor="select-my-sender"
              className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5"
            >
              <User className="w-3.5 h-3.5 text-[#00a884]" />
              <span>Who are You in this Chat? (Outgoing Messages)</span>
            </label>
            <p className="text-xs text-[#8696a0]">
              Messages sent by this participant will appear on the right side in green bubbles.
            </p>
            <select
              id="select-my-sender"
              value={mySenderName}
              onChange={(e) => onSetMySender(e.target.value)}
              className={`w-full p-2.5 rounded-xl border text-sm font-medium outline-none transition-colors cursor-pointer ${
                isDark
                  ? 'bg-[#202c33] border-[#2a3942] text-[#e9edef] focus:border-[#00a884]'
                  : 'bg-[#f8fafc] border-[#cbd5e1] text-[#111b21] focus:border-[#00a884]'
              }`}
            >
              {chatData.participants.map((p) => (
                <option key={p.name} value={p.name}>
                  {p.name} ({p.messageCount} messages)
                </option>
              ))}
            </select>
          </div>

          {/* 2. Theme Mode */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>Appearance Theme</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                id="btn-theme-light"
                onClick={() => onSetTheme('light')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-xs font-medium transition-all cursor-pointer ${
                  theme === 'light'
                    ? 'border-[#00a884] bg-[#00a884]/10 text-[#00a884] font-semibold'
                    : isDark
                    ? 'border-[#222e35] bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]'
                    : 'border-[#e2e8f0] bg-[#f8fafc] text-[#64748b] hover:text-[#111b21]'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>Light</span>
              </button>

              <button
                type="button"
                id="btn-theme-dark"
                onClick={() => onSetTheme('dark')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-xs font-medium transition-all cursor-pointer ${
                  theme === 'dark'
                    ? 'border-[#00a884] bg-[#00a884]/10 text-[#00a884] font-semibold'
                    : isDark
                    ? 'border-[#222e35] bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]'
                    : 'border-[#e2e8f0] bg-[#f8fafc] text-[#64748b] hover:text-[#111b21]'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>Dark</span>
              </button>

              <button
                type="button"
                id="btn-theme-system"
                onClick={() => onSetTheme('system')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 text-xs font-medium transition-all cursor-pointer ${
                  theme === 'system'
                    ? 'border-[#00a884] bg-[#00a884]/10 text-[#00a884] font-semibold'
                    : isDark
                    ? 'border-[#222e35] bg-[#202c33] text-[#8696a0] hover:text-[#e9edef]'
                    : 'border-[#e2e8f0] bg-[#f8fafc] text-[#64748b] hover:text-[#111b21]'
                }`}
              >
                <Monitor className="w-4 h-4" />
                <span>System</span>
              </button>
            </div>
          </div>

          {/* 3. Font Size */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5 text-blue-500" />
              <span>Message Text Size</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                id="btn-font-small"
                onClick={() => onSetFontSize('small')}
                className={`p-2.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                  fontSize === 'small'
                    ? 'border-[#00a884] bg-[#00a884]/10 text-[#00a884] font-semibold'
                    : isDark
                    ? 'border-[#222e35] bg-[#202c33] text-[#8696a0]'
                    : 'border-[#e2e8f0] bg-[#f8fafc] text-[#64748b]'
                }`}
              >
                Small (12px)
              </button>

              <button
                type="button"
                id="btn-font-medium"
                onClick={() => onSetFontSize('medium')}
                className={`p-2.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                  fontSize === 'medium'
                    ? 'border-[#00a884] bg-[#00a884]/10 text-[#00a884] font-semibold'
                    : isDark
                    ? 'border-[#222e35] bg-[#202c33] text-[#8696a0]'
                    : 'border-[#e2e8f0] bg-[#f8fafc] text-[#64748b]'
                }`}
              >
                Medium (14px)
              </button>

              <button
                type="button"
                id="btn-font-large"
                onClick={() => onSetFontSize('large')}
                className={`p-2.5 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                  fontSize === 'large'
                    ? 'border-[#00a884] bg-[#00a884]/10 text-[#00a884] font-semibold'
                    : isDark
                    ? 'border-[#222e35] bg-[#202c33] text-[#8696a0]'
                    : 'border-[#e2e8f0] bg-[#f8fafc] text-[#64748b]'
                }`}
              >
                Large (16px)
              </button>
            </div>
          </div>

          {/* 4. Format & File details */}
          <div
            className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
              isDark ? 'bg-[#182229] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
            }`}
          >
            <div className="font-semibold text-[#8696a0] uppercase tracking-wider text-[10px] flex items-center gap-1.5">
              <FileCheck className="w-3.5 h-3.5 text-[#00a884]" />
              <span>Export Information</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8696a0]">Detected Format:</span>
              <span className="font-medium">{chatData.detectedFormat}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8696a0]">File Name:</span>
              <span className="font-medium truncate max-w-[200px]">{chatData.fileName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8696a0]">Total Messages:</span>
              <span className="font-medium">{chatData.messages.length.toLocaleString()}</span>
            </div>
          </div>

          {/* 5. Privacy Notice */}
          <div
            className={`p-3.5 rounded-xl border flex items-start gap-2.5 ${
              isDark
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
                : 'bg-emerald-50 border-emerald-200 text-emerald-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed">
              <span className="font-semibold">Privacy Guaranteed: </span>
              Your chat is processed locally in your browser and is not uploaded to a server.
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div
          className={`p-4 border-t flex justify-end ${
            isDark ? 'border-[#222e35] bg-[#182229]' : 'border-[#e9edef] bg-[#f8fafc]'
          }`}
        >
          <button
            type="button"
            id="btn-close-settings-modal"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#00a884] hover:bg-[#008069] text-white text-sm font-semibold transition-colors shadow-xs cursor-pointer"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
