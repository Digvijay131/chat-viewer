import React, { useEffect, useRef } from 'react';
import { Search, X, ChevronUp, ChevronDown, Calendar, User } from 'lucide-react';
import { ChatParticipant } from '../types/chat';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  query: string;
  onQueryChange: (query: string) => void;
  resultCount: number;
  currentIndex: number;
  onNext: () => void;
  onPrev: () => void;
  participants: ChatParticipant[];
  selectedParticipantFilter: string;
  onSelectParticipantFilter: (name: string) => void;
  isDark?: boolean;
}

export const SearchOverlay: React.FC<SearchOverlayProps> = ({
  isOpen,
  onClose,
  query,
  onQueryChange,
  resultCount,
  currentIndex,
  onNext,
  onPrev,
  participants,
  selectedParticipantFilter,
  onSelectParticipantFilter,
  isDark = false,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (e.shiftKey) {
        onPrev();
      } else {
        onNext();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  return (
    <div
      id="search-overlay"
      className={`px-3 py-2.5 border-b shadow-sm flex flex-wrap items-center gap-2 z-20 animate-in fade-in slide-in-from-top-2 duration-150 transition-colors ${
        isDark
          ? 'bg-[#182229] border-[#222e35] text-[#e9edef]'
          : 'bg-[#ffffff] border-[#e9edef] text-[#111b21]'
      }`}
    >
      {/* Search Input Bar */}
      <div
        className={`flex-1 min-w-[200px] flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all ${
          isDark
            ? 'bg-[#202c33] border-[#2a3942] focus-within:border-[#00a884]'
            : 'bg-[#f0f2f5] border-[#d1d7db] focus-within:border-[#00a884]'
        }`}
      >
        <Search className="w-4 h-4 text-[#8696a0] shrink-0" />
        <input
          ref={inputRef}
          id="search-input-field"
          type="text"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Search message text, dates, or senders..."
          className="w-full bg-transparent text-sm outline-none placeholder:text-[#8696a0]"
        />
        {query && (
          <button
            type="button"
            onClick={() => onQueryChange('')}
            className="text-[#8696a0] hover:text-[#54656f] dark:hover:text-[#aebac1] p-0.5 rounded cursor-pointer"
            aria-label="Clear search"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Participant Filter Dropdown */}
      <div className="flex items-center gap-1.5">
        <select
          id="search-participant-select"
          value={selectedParticipantFilter}
          onChange={(e) => onSelectParticipantFilter(e.target.value)}
          className={`text-xs px-2.5 py-1.5 rounded-lg border outline-none cursor-pointer ${
            isDark
              ? 'bg-[#202c33] border-[#2a3942] text-[#d1d7db]'
              : 'bg-[#f0f2f5] border-[#d1d7db] text-[#54656f]'
          }`}
          aria-label="Filter search by participant"
        >
          <option value="">All Senders</option>
          {participants.map((p) => (
            <option key={p.name} value={p.name}>
              {p.name}
            </option>
          ))}
        </select>
      </div>

      {/* Search results counter and navigation */}
      <div className="flex items-center gap-1.5 shrink-0">
        <span className="text-xs text-[#8696a0] font-medium min-w-[70px] text-right">
          {query.trim().length === 0
            ? ''
            : resultCount > 0
            ? `${currentIndex + 1} of ${resultCount}`
            : '0 results'}
        </span>

        <button
          type="button"
          id="btn-search-prev"
          onClick={onPrev}
          disabled={resultCount === 0}
          title="Previous match (Shift+Enter)"
          className="p-1 rounded hover:bg-black/5 dark:hover:bg-white/10 disabled:opacity-30 disabled:pointer-events-none text-[#54656f] dark:text-[#aebac1] cursor-pointer"
          aria-label="Previous match"
        >
          <ChevronUp className="w-4 h-4" />
        </button>

        <button
          type="button"
          id="btn-search-next"
          onClick={onNext}
          disabled={resultCount === 0}
          title="Next match (Enter)"
          className="p-1 rounded hover:bg-black/5 dark:hover:bg-white/10 disabled:opacity-30 disabled:pointer-events-none text-[#54656f] dark:text-[#aebac1] cursor-pointer"
          aria-label="Next match"
        >
          <ChevronDown className="w-4 h-4" />
        </button>

        <button
          type="button"
          id="btn-close-search"
          onClick={onClose}
          title="Close search (Esc)"
          className="p-1 ml-1 rounded hover:bg-black/5 dark:hover:bg-white/10 text-[#54656f] dark:text-[#aebac1] cursor-pointer"
          aria-label="Close search"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
