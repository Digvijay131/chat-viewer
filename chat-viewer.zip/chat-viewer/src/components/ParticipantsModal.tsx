import React from 'react';
import { X, Users, MessageSquare, Image, Award, Check } from 'lucide-react';
import { ChatParticipant } from '../types/chat';

interface ParticipantsModalProps {
  isOpen: boolean;
  onClose: () => void;
  participants: ChatParticipant[];
  mySenderName: string;
  onSetMySender: (name: string) => void;
  isDark?: boolean;
}

export const ParticipantsModal: React.FC<ParticipantsModalProps> = ({
  isOpen,
  onClose,
  participants,
  mySenderName,
  onSetMySender,
  isDark = false,
}) => {
  if (!isOpen) return null;

  const totalMessages = participants.reduce((sum, p) => sum + p.messageCount, 0);

  return (
    <div
      id="participants-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="participants-modal-container"
        className={`w-full max-w-lg rounded-2xl shadow-2xl border flex flex-col max-h-[85vh] overflow-hidden animate-in zoom-in-95 duration-200 ${
          isDark
            ? 'bg-[#111b21] border-[#222e35] text-[#e9edef]'
            : 'bg-white border-[#e2e8f0] text-[#111b21]'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div
          className={`px-5 py-4 flex items-center justify-between border-b ${
            isDark ? 'border-[#222e35] bg-[#202c33]' : 'border-[#e9edef] bg-[#f0f2f5]'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#00a884]/20 text-[#00a884] flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold">Participants ({participants.length})</h2>
              <p className="text-xs text-[#8696a0]">
                {totalMessages.toLocaleString()} total messages in chat
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-[#8696a0] hover:text-[#e9edef] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Info Note */}
        <div
          className={`px-5 py-2.5 text-xs border-b ${
            isDark
              ? 'bg-[#182229] border-[#222e35] text-[#8696a0]'
              : 'bg-[#f8fafc] border-[#e2e8f0] text-[#64748b]'
          }`}
        >
          <span>💡 Select </span>
          <span className="font-semibold text-[#00a884]">"Set as Me"</span>
          <span> to adjust which messages appear on the right side of the chat.</span>
        </div>

        {/* Participants List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {participants.map((participant, index) => {
            const isMe =
              mySenderName &&
              participant.name.toLowerCase() === mySenderName.toLowerCase();

            return (
              <div
                key={participant.name}
                className={`p-3.5 rounded-xl border transition-all ${
                  isMe
                    ? isDark
                      ? 'bg-[#005c4b]/20 border-[#00a884]/40 shadow-xs'
                      : 'bg-[#d9fdd3]/40 border-[#00a884]/30 shadow-xs'
                    : isDark
                    ? 'bg-[#202c33]/60 border-[#222e35] hover:border-[#334651]'
                    : 'bg-[#f8fafc] border-[#e2e8f0] hover:border-[#cbd5e1]'
                }`}
              >
                <div className="flex items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs text-white shrink-0 shadow-xs"
                      style={{ backgroundColor: participant.color }}
                    >
                      {participant.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')
                        .slice(0, 2)
                        .toUpperCase() || 'P'}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-sm truncate">
                          {participant.name}
                        </span>
                        {index === 0 && (
                          <span
                            className="inline-flex items-center gap-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-500"
                            title="Most active sender"
                          >
                            <Award className="w-3 h-3" /> Top
                          </span>
                        )}
                        {isMe && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#00a884]/20 text-[#00a884]">
                            You (Me)
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-[#8696a0] flex items-center gap-3 mt-0.5">
                        <span className="flex items-center gap-1">
                          <MessageSquare className="w-3 h-3" />
                          {participant.messageCount.toLocaleString()} msgs ({participant.percentage}%)
                        </span>
                        {participant.mediaCount > 0 && (
                          <span className="flex items-center gap-1">
                            <Image className="w-3 h-3" />
                            {participant.mediaCount} media
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* "Set as Me" button */}
                  <div>
                    {isMe ? (
                      <div className="flex items-center gap-1 text-xs font-semibold text-[#00a884] px-2.5 py-1 rounded-lg bg-[#00a884]/10">
                        <Check className="w-3.5 h-3.5" />
                        <span>Active</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        id={`btn-set-me-${index}`}
                        onClick={() => onSetMySender(participant.name)}
                        className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                          isDark
                            ? 'bg-[#2a3942] hover:bg-[#324552] text-[#e9edef]'
                            : 'bg-white hover:bg-[#e2e8f0] text-[#111b21] border border-[#d1d7db]'
                        }`}
                      >
                        Set as Me
                      </button>
                    )}
                  </div>
                </div>

                {/* Percentage progress bar */}
                <div
                  className={`w-full h-1.5 rounded-full overflow-hidden ${
                    isDark ? 'bg-[#182229]' : 'bg-[#e2e8f0]'
                  }`}
                >
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.max(participant.percentage, 2)}%`,
                      backgroundColor: participant.color,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div
          className={`p-4 border-t flex justify-end ${
            isDark ? 'border-[#222e35] bg-[#182229]' : 'border-[#e9edef] bg-[#f8fafc]'
          }`}
        >
          <button
            type="button"
            id="btn-close-participants-modal"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#00a884] hover:bg-[#008069] text-white text-sm font-semibold transition-colors shadow-xs cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
