import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { ChevronDown, ArrowDown } from 'lucide-react';
import {
  ChatExportData,
  ChatMessage,
  ThemeMode,
  FontSizeOption,
} from '../types/chat';
import { ChatHeader } from './ChatHeader';
import { SearchOverlay } from './SearchOverlay';
import { MessageBubble } from './MessageBubble';
import { DateSeparator } from './DateSeparator';
import { ParticipantsModal } from './ParticipantsModal';
import { StatisticsModal } from './StatisticsModal';
import { SettingsModal } from './SettingsModal';

interface ChatViewerProps {
  chatData: ChatExportData;
  onBack: () => void;
  theme: ThemeMode;
  onSetTheme: (theme: ThemeMode) => void;
  fontSize: FontSizeOption;
  onSetFontSize: (size: FontSizeOption) => void;
  onUpdateMySender: (name: string) => void;
  isDark?: boolean;
}

export const ChatViewer: React.FC<ChatViewerProps> = ({
  chatData,
  onBack,
  theme,
  onSetTheme,
  fontSize,
  onSetFontSize,
  onUpdateMySender,
  isDark = false,
}) => {
  // Modal states
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isParticipantsOpen, setIsParticipantsOpen] = useState(false);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedParticipantFilter, setSelectedParticipantFilter] = useState('');
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);

  // Scroll state
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showScrollBottomBtn, setShowScrollBottomBtn] = useState(false);

  // Participant color lookup map
  const participantColorMap = useMemo(() => {
    const map = new Map<string, string>();
    chatData.participants.forEach((p) => {
      map.set(p.name, p.color);
    });
    return map;
  }, [chatData.participants]);

  // Filtered / Searched messages lookup
  const searchMatchingIndices = useMemo(() => {
    if (!searchQuery.trim() && !selectedParticipantFilter) return [];

    const queryLower = searchQuery.trim().toLowerCase();
    const matches: number[] = [];

    chatData.messages.forEach((msg, idx) => {
      // Participant filter
      if (
        selectedParticipantFilter &&
        msg.sender.toLowerCase() !== selectedParticipantFilter.toLowerCase()
      ) {
        return;
      }

      if (!queryLower) {
        matches.push(idx);
        return;
      }

      const contentMatch = msg.content.toLowerCase().includes(queryLower);
      const senderMatch = msg.sender.toLowerCase().includes(queryLower);
      const dateMatch = msg.dateStr.includes(queryLower) || msg.displayDate.toLowerCase().includes(queryLower);

      if (contentMatch || senderMatch || dateMatch) {
        matches.push(idx);
      }
    });

    return matches;
  }, [chatData.messages, searchQuery, selectedParticipantFilter]);

  // Reset match index when query changes
  useEffect(() => {
    setCurrentMatchIndex(0);
  }, [searchQuery, selectedParticipantFilter]);

  // Scroll to active search match
  const scrollToMatch = useCallback(
    (indexInMatches: number) => {
      if (searchMatchingIndices.length === 0) return;
      const messageIndex = searchMatchingIndices[indexInMatches];
      if (messageIndex === undefined) return;

      const targetMsg = chatData.messages[messageIndex];
      if (!targetMsg) return;

      const element = document.getElementById(targetMsg.id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    },
    [searchMatchingIndices, chatData.messages]
  );

  const handleNextSearch = () => {
    if (searchMatchingIndices.length === 0) return;
    const nextIdx = (currentMatchIndex + 1) % searchMatchingIndices.length;
    setCurrentMatchIndex(nextIdx);
    scrollToMatch(nextIdx);
  };

  const handlePrevSearch = () => {
    if (searchMatchingIndices.length === 0) return;
    const prevIdx =
      (currentMatchIndex - 1 + searchMatchingIndices.length) % searchMatchingIndices.length;
    setCurrentMatchIndex(prevIdx);
    scrollToMatch(prevIdx);
  };

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Initial scroll to bottom (most recent message)
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
    }
  }, [chatData.messages]);

  // Scroll position monitor for floating "scroll to bottom" button
  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    setShowScrollBottomBtn(distanceFromBottom > 350);
  };

  const scrollToTop = () => {
    scrollContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToBottom = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  };

  const activeMessageId =
    searchMatchingIndices.length > 0
      ? chatData.messages[searchMatchingIndices[currentMatchIndex]]?.id
      : undefined;

  return (
    <div
      id="chat-viewer-container"
      className={`h-screen w-full flex flex-col overflow-hidden select-text transition-colors ${
        isDark ? 'bg-[#0b141a]' : 'bg-[#e5ddd5]'
      }`}
    >
      {/* Centered chat window wrapper */}
      <div className="w-full max-w-4xl mx-auto h-full flex flex-col shadow-2xl relative">
        {/* Header */}
        <ChatHeader
          chatData={chatData}
          onBack={onBack}
          onOpenSearch={() => setIsSearchOpen((prev) => !prev)}
          onOpenParticipants={() => setIsParticipantsOpen(true)}
          onOpenStats={() => setIsStatsOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onScrollToTop={scrollToTop}
          onScrollToBottom={scrollToBottom}
          isSearchOpen={isSearchOpen}
          isDark={isDark}
        />

        {/* Search Overlay */}
        <SearchOverlay
          isOpen={isSearchOpen}
          onClose={() => {
            setIsSearchOpen(false);
            setSearchQuery('');
            setSelectedParticipantFilter('');
          }}
          query={searchQuery}
          onQueryChange={setSearchQuery}
          resultCount={searchMatchingIndices.length}
          currentIndex={currentMatchIndex}
          onNext={handleNextSearch}
          onPrev={handlePrevSearch}
          participants={chatData.participants}
          selectedParticipantFilter={selectedParticipantFilter}
          onSelectParticipantFilter={setSelectedParticipantFilter}
          isDark={isDark}
        />

        {/* Chat Messages Scrolling Body */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          id="messages-viewport"
          className="flex-1 overflow-y-auto overflow-x-hidden relative p-2 sm:p-4 whatsapp-chat-bg"
          style={{
            backgroundImage: isDark
              ? `radial-gradient(#1f2c34 1px, transparent 1px), radial-gradient(#182229 1px, transparent 1px)`
              : `radial-gradient(#d1c7bc 1px, transparent 1px), radial-gradient(#dfd5ca 1px, transparent 1px)`,
            backgroundSize: '32px 32px',
            backgroundPosition: '0 0, 16px 16px',
            backgroundColor: isDark ? '#0b141a' : '#efeae2',
          }}
        >
          {/* WhatsApp Encrypted Security Banner */}
          <div className="flex justify-center my-3 select-none">
            <div
              className={`px-3.5 py-1.5 rounded-lg text-xs leading-normal text-center shadow-xs max-w-md ${
                isDark
                  ? 'bg-[#182229]/95 text-[#ffd279] border border-[#222e35]'
                  : 'bg-[#ffeecd] text-[#54656f] border border-[#fae2a6]'
              }`}
            >
              🔒 Messages and calls are end-to-end encrypted. No one outside of this chat, not even
              WhatsApp, can read or listen to them.
            </div>
          </div>

          {/* Render all messages with Date Separators */}
          {chatData.messages.map((msg, index) => {
            const prevMsg = index > 0 ? chatData.messages[index - 1] : null;
            const isDifferentDay = !prevMsg || prevMsg.dateStr !== msg.dateStr;
            const isMatch = activeMessageId === msg.id;

            return (
              <React.Fragment key={msg.id}>
                {isDifferentDay && (
                  <DateSeparator dateText={msg.dateStr} isDark={isDark} />
                )}
                <MessageBubble
                  message={msg}
                  isGroupChat={chatData.isGroupChat}
                  senderColor={participantColorMap.get(msg.sender)}
                  searchQuery={searchQuery}
                  isSearchActive={isMatch}
                  fontSize={fontSize}
                  isDark={isDark}
                />
              </React.Fragment>
            );
          })}
        </div>

        {/* Floating Scroll to Bottom Button */}
        {showScrollBottomBtn && (
          <button
            type="button"
            id="btn-floating-scroll-bottom"
            onClick={scrollToBottom}
            className={`absolute bottom-5 right-5 sm:right-8 w-11 h-11 rounded-full shadow-lg flex items-center justify-center transition-all hover:scale-110 active:scale-95 cursor-pointer z-30 ${
              isDark
                ? 'bg-[#202c33] text-[#00a884] border border-[#2a3942] hover:bg-[#2a3942]'
                : 'bg-white text-[#00a884] border border-[#e2e8f0] hover:bg-[#f8fafc]'
            }`}
            title="Scroll to latest message"
            aria-label="Scroll to latest message"
          >
            <ChevronDown className="w-6 h-6 stroke-[2.5]" />
          </button>
        )}
      </div>

      {/* Modals */}
      <ParticipantsModal
        isOpen={isParticipantsOpen}
        onClose={() => setIsParticipantsOpen(false)}
        participants={chatData.participants}
        mySenderName={chatData.mySenderName}
        onSetMySender={onUpdateMySender}
        isDark={isDark}
      />

      <StatisticsModal
        isOpen={isStatsOpen}
        onClose={() => setIsStatsOpen(false)}
        chatData={chatData}
        isDark={isDark}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        chatData={chatData}
        mySenderName={chatData.mySenderName}
        onSetMySender={onUpdateMySender}
        theme={theme}
        onSetTheme={onSetTheme}
        fontSize={fontSize}
        onSetFontSize={onSetFontSize}
        isDark={isDark}
      />
    </div>
  );
};
