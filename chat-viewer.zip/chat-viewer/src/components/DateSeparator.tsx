import React from 'react';

interface DateSeparatorProps {
  dateText: string;
  isDark?: boolean;
}

export const DateSeparator: React.FC<DateSeparatorProps> = ({ dateText, isDark = false }) => {
  // Format today / yesterday if applicable
  const getFormattedDate = (raw: string) => {
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    const formatISO = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

    if (raw === formatISO(today)) return 'TODAY';
    if (raw === formatISO(yesterday)) return 'YESTERDAY';

    return raw.toUpperCase();
  };

  return (
    <div className="flex justify-center my-3 sticky top-2 z-10 select-none pointer-events-none">
      <div
        className={`px-3 py-1 rounded-lg text-xs font-semibold uppercase tracking-wider shadow-xs backdrop-blur-xs transition-colors ${
          isDark
            ? 'bg-[#182229]/90 text-[#8696a0] border border-[#222e35]'
            : 'bg-[#ffffff]/90 text-[#54656f] border border-[#e9edef]'
        }`}
      >
        {getFormattedDate(dateText)}
      </div>
    </div>
  );
};
