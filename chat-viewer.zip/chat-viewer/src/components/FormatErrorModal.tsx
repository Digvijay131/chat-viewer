import React from 'react';
import { AlertCircle, HelpCircle, FileText, RefreshCw, Sparkles, X } from 'lucide-react';

interface FormatErrorModalProps {
  isOpen: boolean;
  onClose: () => void;
  errorMessage?: string;
  rawSample?: string;
  onTrySample: () => void;
  isDark?: boolean;
}

export const FormatErrorModal: React.FC<FormatErrorModalProps> = ({
  isOpen,
  onClose,
  errorMessage = 'Unable to recognize this WhatsApp export format.',
  rawSample = '',
  onTrySample,
  isDark = false,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="format-error-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="format-error-modal-container"
        className={`w-full max-w-lg rounded-2xl shadow-2xl border flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200 ${
          isDark
            ? 'bg-[#111b21] border-[#222e35] text-[#e9edef]'
            : 'bg-white border-[#e2e8f0] text-[#111b21]'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className={`px-5 py-4 flex items-center justify-between border-b ${
            isDark ? 'border-[#222e35] bg-[#202c33]' : 'border-[#e9edef] bg-[#f0f2f5]'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-red-500/20 text-red-500 flex items-center justify-center">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-red-500">Export Format Unrecognized</h2>
              <p className="text-xs text-[#8696a0]">Parsing diagnostic</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-[#8696a0] hover:text-[#e9edef] transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          <p className="text-sm font-medium">{errorMessage}</p>

          {/* Sample Snippet */}
          {rawSample && (
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-[#8696a0] flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" />
                <span>Detected File Content Preview:</span>
              </div>
              <pre
                className={`p-3 rounded-xl text-xs font-mono overflow-x-auto max-h-36 border whitespace-pre-wrap ${
                  isDark
                    ? 'bg-[#182229] border-[#222e35] text-amber-300/90'
                    : 'bg-[#f8fafc] border-[#e2e8f0] text-slate-700'
                }`}
              >
                {rawSample}
              </pre>
            </div>
          )}

          {/* How to export properly guide */}
          <div
            className={`p-4 rounded-xl border space-y-2 text-xs ${
              isDark ? 'bg-[#182229] border-[#222e35]' : 'bg-[#f8fafc] border-[#e2e8f0]'
            }`}
          >
            <div className="font-semibold text-[#00a884] flex items-center gap-1.5 text-xs">
              <HelpCircle className="w-4 h-4" />
              <span>How to Export Chats Directly from WhatsApp:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-[#8696a0] pl-1">
              <li>
                <strong className="text-[#111b21] dark:text-[#e9edef]">Android:</strong> Open chat &gt;
                tap ⋮ (3 dots) &gt; More &gt; <em>Export chat</em> &gt; select <em>Without media</em>.
              </li>
              <li>
                <strong className="text-[#111b21] dark:text-[#e9edef]">iOS / iPhone:</strong> Open chat &gt;
                tap contact/group name at top &gt; scroll down &gt; <em>Export Chat</em> &gt; <em>Without Media</em>.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div
          className={`p-4 border-t flex flex-wrap gap-2 justify-between items-center ${
            isDark ? 'border-[#222e35] bg-[#182229]' : 'border-[#e9edef] bg-[#f8fafc]'
          }`}
        >
          <button
            type="button"
            id="btn-error-try-sample"
            onClick={() => {
              onClose();
              onTrySample();
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-[#00a884]/15 hover:bg-[#00a884]/25 text-[#00a884] transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Try a Sample Chat</span>
          </button>

          <button
            type="button"
            id="btn-error-try-again"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#00a884] hover:bg-[#008069] text-white text-xs font-semibold transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Try Another File</span>
          </button>
        </div>
      </div>
    </div>
  );
};
