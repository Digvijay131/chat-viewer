import React, { useState } from 'react';
import {
  CheckCheck,
  Camera,
  Video,
  FileText,
  MapPin,
  User,
  Ban,
  PhoneMissed,
  Play,
  Pause,
  ExternalLink,
  ShieldCheck,
  Info,
} from 'lucide-react';
import { ChatMessage, FontSizeOption } from '../types/chat';

interface MessageBubbleProps {
  message: ChatMessage;
  isGroupChat: boolean;
  senderColor?: string;
  searchQuery?: string;
  isSearchActive?: boolean;
  fontSize?: FontSizeOption;
  isDark?: boolean;
}

// Regex to detect purely 1-3 emojis for larger display
const PURE_EMOJI_REGEX = /^(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|[\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|[\ud83c[\ude32-\ude3a]|[\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|[\ud83c\udca0-\udcff]|[\ud83d\udc00-\udfff]|[\ud83e\udc00-\udfff]|\s)+$/;

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isGroupChat,
  senderColor = '#00a884',
  searchQuery = '',
  isSearchActive = false,
  fontSize = 'medium',
  isDark = false,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Font size classes
  const textFontSize =
    fontSize === 'small' ? 'text-xs' : fontSize === 'large' ? 'text-base' : 'text-sm';
  const metaFontSize = fontSize === 'small' ? 'text-[10px]' : 'text-[11px]';

  // Format and highlight content with URLs and search queries
  const renderFormattedText = (text: string) => {
    if (!text) return null;

    // Check if it's purely a few emojis
    const isPureEmoji = text.length <= 12 && PURE_EMOJI_REGEX.test(text.trim());

    // Split text by URLs and Search Query
    const urlPattern = /(https?:\/\/[^\s]+|www\.[^\s]+)/gi;
    const parts = text.split(urlPattern);

    return (
      <span className={`leading-relaxed break-words ${isPureEmoji ? 'text-2xl sm:text-3xl' : ''}`}>
        {parts.map((part, i) => {
          if (part.match(urlPattern)) {
            const href = part.startsWith('http') ? part : `https://${part}`;
            return (
              <a
                key={i}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className={`inline-flex items-baseline gap-0.5 underline transition-colors ${
                  isDark ? 'text-[#53bdeb] hover:text-[#70c9f1]' : 'text-[#027eb5] hover:text-[#015f8a]'
                }`}
                onClick={(e) => e.stopPropagation()}
              >
                {part}
                <ExternalLink className="w-3 h-3 inline self-center opacity-70 ml-0.5" />
              </a>
            );
          }

          // Highlight search query if present
          if (searchQuery && searchQuery.trim().length > 0) {
            const regex = new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
            const subParts = part.split(regex);
            return subParts.map((sub, j) =>
              regex.test(sub) ? (
                <mark
                  key={`${i}-${j}`}
                  className={`${
                    isSearchActive ? 'bg-amber-400 text-slate-900 font-bold' : 'bg-yellow-200 text-slate-900'
                  } rounded-xs px-0.5`}
                >
                  {sub}
                </mark>
              ) : (
                sub
              )
            );
          }

          return part;
        })}
      </span>
    );
  };

  // 1. System Messages (Centered banner)
  if (message.isSystemMessage) {
    const isEncryptedNotice = message.content.toLowerCase().includes('end-to-end encrypted');
    return (
      <div
        id={message.id}
        className="flex justify-center my-2.5 px-4 select-none"
      >
        <div
          className={`max-w-md px-3.5 py-1.5 rounded-lg text-xs leading-normal text-center shadow-xs flex items-center gap-1.5 ${
            isDark
              ? 'bg-[#182229]/95 text-[#ffd279] border border-[#222e35]'
              : 'bg-[#ffeecd] text-[#54656f] border border-[#fae2a6]'
          }`}
        >
          {isEncryptedNotice ? (
            <ShieldCheck className="w-3.5 h-3.5 text-[#e5a824] shrink-0" />
          ) : (
            <Info className="w-3.5 h-3.5 text-[#8696a0] shrink-0" />
          )}
          <span>{message.content}</span>
        </div>
      </div>
    );
  }

  // 2. Deleted Message
  if (message.isDeleted) {
    return (
      <div
        id={message.id}
        className={`flex ${message.isOutgoing ? 'justify-end' : 'justify-start'} my-1 px-2 sm:px-4`}
      >
        <div
          className={`max-w-[85%] sm:max-w-[70%] rounded-lg px-3 py-1.5 shadow-xs flex items-center gap-2 italic ${
            message.isOutgoing
              ? isDark
                ? 'bg-[#005c4b] text-[#8696a0]'
                : 'bg-[#d9fdd3] text-[#667781]'
              : isDark
              ? 'bg-[#202c33] text-[#8696a0]'
              : 'bg-[#ffffff] text-[#667781]'
          } ${textFontSize}`}
        >
          <Ban className="w-3.5 h-3.5 opacity-60 shrink-0" />
          <span>{message.content || 'This message was deleted'}</span>
          <span className={`text-[10px] ml-1.5 opacity-70 not-italic`}>{message.timeStr}</span>
        </div>
      </div>
    );
  }

  // 3. Call Notification
  if (message.type === 'call') {
    return (
      <div id={message.id} className="flex justify-center my-2 px-4 select-none">
        <div
          className={`px-3 py-1 rounded-lg text-xs flex items-center gap-1.5 shadow-xs ${
            isDark ? 'bg-[#202c33] text-[#e9edef]' : 'bg-[#ffffff] text-[#54656f]'
          }`}
        >
          <PhoneMissed className="w-3.5 h-3.5 text-red-500 shrink-0" />
          <span>{message.content}</span>
          <span className="text-[10px] text-gray-400 ml-1">{message.timeStr}</span>
        </div>
      </div>
    );
  }

  // 4. Regular / Media / Rich Bubbles
  const isOutgoing = message.isOutgoing;

  return (
    <div
      id={message.id}
      className={`flex ${isOutgoing ? 'justify-end' : 'justify-start'} my-1 px-2 sm:px-4 transition-colors`}
    >
      <div
        className={`relative max-w-[88%] sm:max-w-[72%] md:max-w-[62%] rounded-xl px-3 pt-2 pb-1.5 shadow-xs group transition-shadow ${
          isOutgoing
            ? isDark
              ? 'bg-[#005c4b] text-[#e9edef] rounded-tr-none'
              : 'bg-[#d9fdd3] text-[#111b21] rounded-tr-none'
            : isDark
            ? 'bg-[#202c33] text-[#e9edef] rounded-tl-none'
            : 'bg-[#ffffff] text-[#111b21] rounded-tl-none'
        } ${isSearchActive ? 'ring-2 ring-amber-400 shadow-md' : ''}`}
      >
        {/* Sender Name for incoming messages in group chats */}
        {!isOutgoing && isGroupChat && (
          <div
            className="text-xs font-semibold mb-1 cursor-default select-none tracking-tight"
            style={{ color: senderColor }}
          >
            {message.sender}
          </div>
        )}

        {/* Media Placeholders / Special cards */}
        {message.isMedia && (
          <div className="mb-2">
            {message.type === 'image' && (
              <div
                className={`rounded-lg p-3 flex flex-col items-center justify-center gap-1.5 border border-dashed ${
                  isDark
                    ? 'bg-[#182229]/60 border-[#334651] text-[#aebac1]'
                    : 'bg-[#f0f2f5] border-[#d1d7db] text-[#54656f]'
                }`}
              >
                <div className="w-10 h-10 rounded-full flex items-center justify-center bg-emerald-500/10 text-emerald-500">
                  <Camera className="w-5 h-5" />
                </div>
                <div className="text-xs font-medium">📷 Photo</div>
                <div className="text-[11px] opacity-75 text-center">
                  Media was not included in the exported chat.
                </div>
              </div>
            )}

            {message.type === 'video' && (
              <div
                className={`rounded-lg p-3 flex flex-col items-center justify-center gap-1.5 border border-dashed ${
                  isDark
                    ? 'bg-[#182229]/60 border-[#334651] text-[#aebac1]'
                    : 'bg-[#f0f2f5] border-[#d1d7db] text-[#54656f]'
                }`}
              >
                <div className="w-10 h-10 rounded-full flex items-center justify-center bg-blue-500/10 text-blue-500">
                  <Video className="w-5 h-5" />
                </div>
                <div className="text-xs font-medium">🎥 Video</div>
                <div className="text-[11px] opacity-75 text-center">
                  Media was not included in the exported chat.
                </div>
              </div>
            )}

            {message.type === 'audio' && (
              <div
                className={`rounded-lg p-2.5 flex items-center gap-3 border ${
                  isDark
                    ? 'bg-[#182229]/80 border-[#334651] text-[#e9edef]'
                    : 'bg-[#f0f2f5] border-[#e2e8f0] text-[#111b21]'
                }`}
              >
                <button
                  type="button"
                  id={`play-audio-${message.id}`}
                  onClick={() => setIsPlayingAudio(!isPlayingAudio)}
                  aria-label={isPlayingAudio ? 'Pause Voice Note' : 'Play Voice Note'}
                  className="w-9 h-9 rounded-full bg-[#00a884] text-white flex items-center justify-center hover:bg-[#008069] transition-colors shrink-0 shadow-xs cursor-pointer"
                >
                  {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>
                <div className="flex-1 min-w-[120px]">
                  <div className="flex items-center gap-0.5 h-6 mb-1">
                    {[4, 8, 14, 20, 12, 18, 16, 22, 10, 15, 12, 8, 18, 14, 10, 16, 6].map((h, i) => (
                      <div
                        key={i}
                        className={`flex-1 rounded-full transition-all duration-200 ${
                          isPlayingAudio && i % 3 === 0
                            ? 'bg-[#00a884] animate-pulse'
                            : isDark
                            ? 'bg-[#667781]'
                            : 'bg-[#8696a0]'
                        }`}
                        style={{ height: `${h}px` }}
                      />
                    ))}
                  </div>
                  <div className="flex justify-between items-center text-[10px] text-[#8696a0]">
                    <span>Voice note</span>
                    <span>{message.mediaDetails?.duration || '0:14'}</span>
                  </div>
                </div>
              </div>
            )}

            {message.type === 'document' && (
              <div
                className={`rounded-lg p-2.5 flex items-center gap-3 border ${
                  isDark
                    ? 'bg-[#182229]/80 border-[#334651] text-[#e9edef]'
                    : 'bg-[#f0f2f5] border-[#e2e8f0] text-[#111b21]'
                }`}
              >
                <div className="w-9 h-9 rounded-lg bg-red-500/10 text-red-500 flex items-center justify-center shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium truncate">
                    {message.mediaDetails?.filename || 'Document.pdf'}
                  </div>
                  <div className="text-[10px] text-[#8696a0]">
                    {message.mediaDetails?.fileSize || 'Document file'}
                  </div>
                </div>
              </div>
            )}

            {message.type === 'location' && (
              <div
                className={`rounded-lg p-2.5 flex items-center gap-3 border ${
                  isDark
                    ? 'bg-[#182229]/80 border-[#334651] text-[#e9edef]'
                    : 'bg-[#f0f2f5] border-[#e2e8f0] text-[#111b21]'
                }`}
              >
                <div className="w-9 h-9 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium">📍 Live / Shared Location</div>
                  <div className="text-[10px] text-[#8696a0] truncate">
                    {message.content || 'Map Location'}
                  </div>
                </div>
              </div>
            )}

            {message.type === 'contact' && (
              <div
                className={`rounded-lg p-2.5 flex items-center gap-3 border ${
                  isDark
                    ? 'bg-[#182229]/80 border-[#334651] text-[#e9edef]'
                    : 'bg-[#f0f2f5] border-[#e2e8f0] text-[#111b21]'
                }`}
              >
                <div className="w-9 h-9 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center shrink-0">
                  <User className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium">Contact Card</div>
                  <div className="text-[10px] text-[#8696a0]">
                    {message.content || 'Contact Info'}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Message Body Content (if not purely media placeholder with no additional caption) */}
        {message.content &&
          !['<media omitted>', 'image omitted', 'video omitted', 'sticker omitted'].includes(
            message.content.trim().toLowerCase()
          ) && (
            <div className={`whitespace-pre-wrap ${textFontSize} pr-12 pb-1.5`}>
              {renderFormattedText(message.content)}
            </div>
          )}

        {/* Timestamp and Delivery Checkmarks */}
        <div
          className={`flex items-center justify-end gap-1 select-none pointer-events-none float-right ml-2 mt-[-4px] ${metaFontSize} ${
            isDark ? 'text-[#8696a0]' : 'text-[#667781]'
          }`}
        >
          <span>{message.timeStr}</span>
          {isOutgoing && (
            <CheckCheck
              className={`w-3.5 h-3.5 ${
                isDark ? 'text-[#53bdeb]' : 'text-[#53bdeb]'
              }`}
            />
          )}
        </div>
      </div>
    </div>
  );
};
